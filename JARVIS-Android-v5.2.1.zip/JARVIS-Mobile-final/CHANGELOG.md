## 5.2.1\n- Removed Arabic OCR references from the requested scope; Persian remains listed as not yet supported/guaranteed. No other features were removed.\n\n## 5.2.0\n- Added user-confirmed opening of the Android system dialer.\n- Added explicit confirmation before WebDAV cloud backup upload and restore.\n- Updated capability coverage to distinguish implemented features from platform/model limitations.\n\n# Changelog

## 5.2.0
- Added device diagnostics for hardware identifiers, Android API level, total RAM, available app storage, CPU ABIs and installed app version.
- Updated specification notes for Redmi Note 12 Pro hardware variants and Android microphone foreground-service restrictions.


## 5.0.0 — 2026-11-25
- Added foreground live CameraX preview and on-device ML Kit OCR for supported Latin-script text. Persian OCR is not guaranteed by the bundled recognizer.
- Added in-app HTTPS WebView and explicit page-text extraction followed by AI summarization.
- Added a review-before-execute local planner for note, task, and reminder actions.
- Added portable AES-256-GCM encrypted export/import for notes, tasks, approved memory, and recent chat. Users can choose a cloud-backed Android document provider manually or use an explicitly configured HTTPS WebDAV endpoint for manual upload/download.
- Added explicit, user-triggered last-known-location sharing through Android Sharesheet; no automatic tracking or emergency dispatch.
- Added deterministic offline time/date/arithmetic commands (not a local generative AI model).
- Added backup encryption round-trip and wrong-password tests.

## Known limitations
- No always-on wake-word/background microphone service; Android background microphone restrictions and privacy require a separately designed, visibly user-started foreground service and an actual wake-word model.
- No bundled offline LLM; local deterministic commands remain available.
- Video dubbing does not yet produce a translated/muxed video file.
- Ordinary third-party apps cannot freely answer cellular calls or access call audio; no AI call receptionist is claimed.
- Location sharing is manual and uses the most recent cached location; user must review freshness and select recipient.
- Encrypted backup is manual; automatic cloud synchronization is not implemented.
- Full Android build/device tests require Android SDK/Gradle and a physical or virtual device.
