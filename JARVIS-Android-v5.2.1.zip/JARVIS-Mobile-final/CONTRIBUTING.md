# Contributing

1. Open an issue before large changes.
2. Keep user-facing strings localized in both Persian and English.
3. Do not commit API keys, signing keys, `local.properties`, or personal data.
4. Build with JDK 17, Android SDK 35, and Gradle 8.9.
5. Run `gradle :app:assembleDebug` before submitting a pull request.
6. Describe device/API requirements and manual test steps in the pull request.

Pull requests should be focused, documented, and tested. Do not claim a feature works unless it has been exercised on a supported Android device or emulator.
