package com.jarvis.ai.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val detail: String = "",
    val done: Boolean = false,
    val priority: Int = 1,
    val dueAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String = "Preference",
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault")
data class VaultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val uri: String,
    val mimeType: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val fromUser: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface JarvisDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun notes(): Flow<List<NoteEntity>>
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC") suspend fun allNotes(): List<NoteEntity>
    @Insert suspend fun importNotes(items: List<NoteEntity>)
    @Insert suspend fun addNote(note: NoteEntity)
    @Update suspend fun updateNote(note: NoteEntity)
    @Delete suspend fun deleteNote(note: NoteEntity)

    @Query("SELECT * FROM tasks ORDER BY done ASC, createdAt DESC")
    fun tasks(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks ORDER BY done ASC, createdAt DESC") suspend fun allTasks(): List<TaskEntity>
    @Insert suspend fun importTasks(items: List<TaskEntity>)
    @Insert suspend fun addTask(task: TaskEntity)
    @Update suspend fun updateTask(task: TaskEntity)
    @Delete suspend fun deleteTask(task: TaskEntity)

    @Query("SELECT * FROM chat ORDER BY createdAt ASC")
    fun chat(): Flow<List<ChatEntity>>
    @Query("SELECT * FROM chat ORDER BY createdAt ASC") suspend fun allChat(): List<ChatEntity>
    @Insert suspend fun importChat(items: List<ChatEntity>)
    @Insert suspend fun addChat(line: ChatEntity)
    @Query("DELETE FROM chat") suspend fun clearChat()

    @Query("SELECT * FROM memory ORDER BY createdAt DESC")
    fun memories(): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memory ORDER BY createdAt DESC") suspend fun allMemories(): List<MemoryEntity>
    @Insert suspend fun importMemories(items: List<MemoryEntity>)
    @Insert suspend fun addMemory(item: MemoryEntity)
    @Update suspend fun updateMemory(item: MemoryEntity)
    @Delete suspend fun deleteMemory(item: MemoryEntity)
    @Query("DELETE FROM memory") suspend fun clearMemory()

    @Query("SELECT * FROM vault ORDER BY createdAt DESC")
    fun vaultItems(): Flow<List<VaultEntity>>
    @Insert suspend fun addVaultItem(item: VaultEntity)
    @Delete suspend fun deleteVaultItem(item: VaultEntity)
}

@Database(entities = [NoteEntity::class, TaskEntity::class, ChatEntity::class, MemoryEntity::class, VaultEntity::class], version = 2, exportSchema = false)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun dao(): JarvisDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS memory (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, category TEXT NOT NULL, content TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS vault (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, uri TEXT NOT NULL, mimeType TEXT NOT NULL, createdAt INTEGER NOT NULL)")
            }
        }
        @Volatile private var INSTANCE: JarvisDatabase? = null
        fun get(context: Context): JarvisDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, JarvisDatabase::class.java, "jarvis.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { INSTANCE = it }
        }
    }
}
