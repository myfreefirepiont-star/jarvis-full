package com.jarvis.ai

/** Small deterministic arithmetic parser for offline calculations. */
object JarvisCalculator {
    fun evaluate(input: String): Double {
        require(input.isNotBlank()) { "Enter an expression" }
        val parser = Parser(input.replace(',', '.').replace('×', '*').replace('÷', '/'))
        val result = parser.expression()
        parser.skipSpaces()
        require(parser.atEnd()) { "Unexpected character at position ${parser.position + 1}" }
        require(result.isFinite()) { "Result is not finite" }
        return result
    }

    private class Parser(private val source: String) {
        var position = 0
            private set
        fun atEnd() = position >= source.length
        fun skipSpaces() { while (!atEnd() && source[position].isWhitespace()) position++ }
        private fun take(c: Char): Boolean {
            skipSpaces()
            if (!atEnd() && source[position] == c) { position++; return true }
            return false
        }
        fun expression(): Double {
            var value = term()
            while (true) {
                value = when {
                    take('+') -> value + term()
                    take('-') -> value - term()
                    else -> return value
                }
            }
        }
        private fun term(): Double {
            var value = factor()
            while (true) {
                value = when {
                    take('*') -> value * factor()
                    take('/') -> { val divisor = factor(); require(divisor != 0.0) { "Division by zero" }; value / divisor }
                    else -> return value
                }
            }
        }
        private fun factor(): Double {
            skipSpaces()
            if (take('+')) return factor()
            if (take('-')) return -factor()
            if (take('(')) {
                val value = expression()
                require(take(')')) { "Missing closing parenthesis" }
                return value
            }
            skipSpaces()
            val start = position
            var dot = false
            while (!atEnd()) {
                val c = source[position]
                if (c.isDigit()) position++
                else if (c == '.' && !dot) { dot = true; position++ }
                else break
            }
            require(position > start) { "Expected a number at position ${position + 1}" }
            return source.substring(start, position).toDouble()
        }
    }
}


/** Small, deterministic offline intents. This is not a bundled generative language model. */
object OfflineCommandEngine {
    fun answer(raw: String): String? {
        val text = raw.trim()
        val lower = text.lowercase()
        if (listOf("ساعت چنده", "الان ساعت", "what time is it", "current time").any { lower.contains(it) }) {
            return "زمان فعلی دستگاه: " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date())
        }
        if (listOf("امروز چندمه", "تاریخ امروز", "today's date", "what date is it").any { lower.contains(it) }) {
            return "تاریخ دستگاه: " + java.text.DateFormat.getDateInstance(java.text.DateFormat.FULL).format(java.util.Date())
        }
        val normalized = text.map { ch -> when (ch) { in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar(); in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar(); '×' -> '*'; '÷' -> '/'; '٫', ',' -> '.'; else -> ch } }.joinToString("")
        val candidate = normalized.filter { it.isDigit() || it in "+-*/(). " }
        if (candidate.count { it.isDigit() } >= 2 && candidate.any { it in "+*/" }) {
            return try { "نتیجه: ${JarvisCalculator.evaluate(candidate)}" } catch (_: Exception) { null }
        }
        return null
    }
}


fun reminderDelayMillis(input: String): Long {
    val normalized = input.map { ch -> when (ch) { in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar(); in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar(); else -> ch } }.joinToString("").lowercase()
    Regex("(\\d+)\\s*(دقیقه|دقيقه|minutes?|mins?)").find(normalized)?.let { return (it.groupValues[1].toLongOrNull() ?: 60L).coerceIn(1, 10080) * 60_000L }
    Regex("(\\d+)\\s*(ساعت|hours?|hrs?)").find(normalized)?.let { return (it.groupValues[1].toLongOrNull() ?: 1L).coerceIn(1, 168) * 3_600_000L }
    if (normalized.contains("فردا") || normalized.contains("tomorrow")) return 24 * 3_600_000L
    return 60 * 60_000L
}

