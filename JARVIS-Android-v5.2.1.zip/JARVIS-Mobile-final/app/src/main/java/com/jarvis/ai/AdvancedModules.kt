package com.jarvis.ai

import android.Manifest
import android.content.Context
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.concurrent.Executors
import org.json.JSONTokener

@Composable
fun LiveCameraOcr(onOcr: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    var error by remember { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val controller = remember { LifecycleCameraController(context) }
    val executor = remember(granted) { Executors.newSingleThreadExecutor() }
    DisposableEffect(controller, granted) {
        if (granted) {
            controller.cameraSelector = androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA
            controller.setEnabledUseCases(CameraController.IMAGE_CAPTURE)
            runCatching { controller.bindToLifecycle(lifecycle) }.onFailure { error = it.localizedMessage ?: "اتصال دوربین ناموفق بود" }
        }
        onDispose { runCatching { controller.unbind() }; executor.shutdown() }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("دوربین زنده و OCR", color = MaterialTheme.colorScheme.primary)
        if (!granted) Button(onClick = { permission.launch(Manifest.permission.CAMERA) }) { Text("دادن مجوز دوربین") }
        else {
            AndroidView(factory = { PreviewView(it).apply { this.controller = controller; scaleType = PreviewView.ScaleType.FILL_CENTER } }, modifier = Modifier.fillMaxWidth().height(340.dp))
            Button(onClick = {
                val file = File(context.cacheDir, "jarvis-ocr-${System.currentTimeMillis()}.jpg")
                val options = androidx.camera.core.ImageCapture.OutputFileOptions.Builder(file).build()
                controller.takePicture(options, executor, object : androidx.camera.core.ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(result: androidx.camera.core.ImageCapture.OutputFileResults) {
                        try {
                            val image = InputImage.fromFilePath(context, Uri.fromFile(file))
                            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                                .addOnSuccessListener { onOcr(it.text.ifBlank { "متنی در تصویر پیدا نشد." }); file.delete() }
                                .addOnFailureListener { error = it.localizedMessage ?: "OCR ناموفق بود"; file.delete() }
                        } catch (e: Exception) { error = e.localizedMessage ?: "خطا در پردازش تصویر" }
                    }
                    override fun onError(exception: androidx.camera.core.ImageCaptureException) { error = exception.localizedMessage ?: "گرفتن تصویر ناموفق بود" }
                })
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CameraAlt, null); Text("گرفتن تصویر و استخراج متن") }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Text("پیش‌نمایش فقط هنگام باز بودن این صفحه فعال است. عکس با فشردن دکمه گرفته می‌شود و OCR روی دستگاه انجام می‌شود. موتور همراه فعلاً خط لاتین را پشتیبانی می‌کند؛ OCR فارسی در این نسخه تضمین نشده است.")
    }
}

@Composable
fun EmbeddedWebResearch(onSummarize: (String) -> Unit) {
    val context = LocalContext.current
    var address by remember { mutableStateOf("https://www.wikipedia.org") }
    var loaded by remember { mutableStateOf(false) }
    val web = remember { WebView(context).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.safeBrowsingEnabled = true
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                return request.url.scheme != "https"
            }
            override fun onPageFinished(view: WebView, url: String) { loaded = true }
        }
    } }
    DisposableEffect(Unit) { onDispose { web.stopLoading(); web.destroy() } }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("مرورگر و خلاصه‌ساز داخلی", color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(address, { address = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("آدرس HTTPS صفحه") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val input = address.trim()
                val candidate = when {
                    input.startsWith("https://") -> input
                    input.startsWith("http://") -> "https://" + input.removePrefix("http://")
                    input.matches(Regex("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) -> "https://$input"
                    else -> "https://www.google.com/search?q=${Uri.encode(input)}"
                }
                val uri = runCatching { Uri.parse(candidate) }.getOrNull()
                if (uri?.scheme == "https" && !uri.host.isNullOrBlank()) { loaded = false; web.loadUrl(candidate) }
            }, enabled = address.isNotBlank()) { Icon(Icons.Default.Search, null); Text("جست‌وجو / بازکردن") }
            OutlinedButton(enabled = loaded, onClick = {
                web.evaluateJavascript("(function(){return document.body ? document.body.innerText : '';})()") { raw ->
                    val extracted = runCatching { JSONTokener(raw).nextValue().toString() }.getOrDefault("").take(24000)
                    if (extracted.isNotBlank()) onSummarize("Source URL: ${web.url}\n\n$extracted")
                }
            }) { Text("خلاصه با AI") }
        }
        AndroidView(factory = { web }, modifier = Modifier.fillMaxWidth().weight(1f))
        Text("متن صفحه فقط پس از انتخاب دکمهٔ خلاصه استخراج و به سرویس AI تنظیم‌شده ارسال می‌شود. صفحات نیازمند ورود یا محتوای محافظت‌شده ممکن است قابل استخراج نباشند.", style = MaterialTheme.typography.bodySmall)
    }
}

data class PlannedAction(val type: String, val title: String, val detail: String)
fun makePlan(input: String): List<PlannedAction> {
    val text = input.trim()
    if (text.isBlank()) return emptyList()
    val out = mutableListOf<PlannedAction>()
    if (listOf("یادداشت", "note", "save this").any { text.contains(it, true) }) out += PlannedAction("note", "ساخت یادداشت", text)
    if (listOf("وظیفه", "کار", "task", "todo").any { text.contains(it, true) }) out += PlannedAction("task", "ساخت وظیفه", text)
    if (listOf("یادآور", "یادآوری", "remind", "reminder").any { text.contains(it, true) }) out += PlannedAction("reminder", "تنظیم یادآور (زمان نامشخص: یک ساعت بعد)", text)
    if (out.isEmpty()) out += PlannedAction("explain", "نیازمند توضیح بیشتر", "این نسخه فقط عملیات محلی یادداشت، وظیفه و یادآور را می‌تواند پس از تأیید اجرا کند.")
    return out
}

@Composable
fun PlannerScreen(onExecute: (List<PlannedAction>) -> Unit) {
    var request by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf(emptyList<PlannedAction>()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("برنامه‌ریز چندمرحله‌ای", color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(request, { request = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("درخواستت را بنویس؛ مثلاً یادداشت بساز و برای پیگیری یادآور بگذار") })
        Button(onClick = { plan = makePlan(request) }, modifier = Modifier.fillMaxWidth()) { Text("ساخت برنامهٔ پیشنهادی") }
        plan.forEach { item -> ListItem(headlineContent = { Text(item.title) }, supportingContent = { Text(item.detail) }) }
        Button(enabled = plan.isNotEmpty() && plan.none { it.type == "explain" }, onClick = { onExecute(plan); plan = emptyList(); request = "" }, modifier = Modifier.fillMaxWidth()) { Text("تأیید و اجرای عملیات") }
        Text("هیچ عملیات بیرونی، ارسال پیام یا اقدام حساس بدون تأیید صریح انجام نمی‌شود.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun EncryptedBackupScreen(
    onExport: (String) -> Unit,
    onImport: (String) -> Unit,
    onCloudUpload: (String, String, String, String) -> Unit,
    onCloudDownload: (String, String, String, String) -> Unit
) {
    var password by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var cloudPassword by remember { mutableStateOf("") }
    var pendingCloudAction by remember { mutableStateOf("") }
    var pendingEndpoint by remember { mutableStateOf("") }
    var pendingUsername by remember { mutableStateOf("") }
    var pendingCloudPassword by remember { mutableStateOf("") }
    var pendingBackupPassword by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("پشتیبان رمزگذاری‌شده", color = MaterialTheme.colorScheme.primary)
        Text("از یادداشت‌ها، وظایف، حافظهٔ تأییدشده و گفتگوها یک فایل AES-GCM رمزگذاری‌شده می‌سازد. فایل را می‌توانی در فضای ابری انتخابی خودت ذخیره کنی.")
        OutlinedTextField(password, { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("گذرواژهٔ پشتیبان (حداقل ۱۰ نویسه)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        Button(onClick = { val value = password; onExport(value); password = "" }, enabled = password.length >= 10, modifier = Modifier.fillMaxWidth()) { Text("ساخت فایل پشتیبان رمزگذاری‌شده") }
        OutlinedButton(onClick = { val value = password; onImport(value); password = "" }, enabled = password.length >= 10, modifier = Modifier.fillMaxWidth()) { Text("بازیابی از فایل پشتیبان") }
        Divider()
        Text("انتقال دستی به فضای ابری شخصی (WebDAV)", color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(endpoint, { endpoint = it }, modifier = Modifier.fillMaxWidth(), label = { Text("نشانی کامل HTTPS فایل WebDAV") }, singleLine = true)
        OutlinedTextField(username, { username = it }, modifier = Modifier.fillMaxWidth(), label = { Text("نام کاربری WebDAV") }, singleLine = true)
        OutlinedTextField(cloudPassword, { cloudPassword = it }, modifier = Modifier.fillMaxWidth(), label = { Text("گذرواژه WebDAV") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        Button(onClick = {
            pendingCloudAction = "upload"; pendingEndpoint = endpoint; pendingUsername = username
            pendingCloudPassword = cloudPassword; pendingBackupPassword = password
        }, enabled = endpoint.startsWith("https://") && username.isNotBlank() && password.length >= 10, modifier = Modifier.fillMaxWidth()) { Text("بارگذاری نسخهٔ رمزگذاری‌شده") }
        OutlinedButton(onClick = {
            pendingCloudAction = "download"; pendingEndpoint = endpoint; pendingUsername = username
            pendingCloudPassword = cloudPassword; pendingBackupPassword = password
        }, enabled = endpoint.startsWith("https://") && username.isNotBlank() && password.length >= 10, modifier = Modifier.fillMaxWidth()) { Text("دریافت و بازیابی نسخهٔ ابری") }
        Text("انتقال ابری فقط با فشردن دکمه انجام می‌شود. فایل قبل از ارسال با AES-GCM رمز می‌شود؛ نشانی، نام کاربری و گذرواژهٔ WebDAV در برنامه ذخیره نمی‌شوند. برای WebDAV به سرور/حساب سازگار نیاز داری؛ هزینه یا محدودیت سرویس به ارائه‌دهنده بستگی دارد.", style = MaterialTheme.typography.bodySmall)
    }

    if (pendingCloudAction.isNotBlank()) {
        val uploading = pendingCloudAction == "upload"
        AlertDialog(
            onDismissRequest = { pendingCloudAction = "" },
            title = { Text(if (uploading) "تأیید بارگذاری ابری" else "تأیید بازیابی ابری") },
            text = { Text(if (uploading)
                "یک نسخهٔ پشتیبان رمزگذاری‌شده به نشانی WebDAV انتخاب‌شده ارسال می‌شود. ادامه می‌دهی؟"
                else "اطلاعات موجود با نسخهٔ پشتیبان ابری ادغام می‌شود. ممکن است موارد تکراری ایجاد شوند. ادامه می‌دهی؟") },
            confirmButton = { TextButton(onClick = {
                val ep = pendingEndpoint; val user = pendingUsername; val cp = pendingCloudPassword; val bp = pendingBackupPassword
                pendingCloudAction = ""; password = ""; cloudPassword = ""
                if (uploading) onCloudUpload(ep, user, cp, bp) else onCloudDownload(ep, user, cp, bp)
            }) { Text("تأیید") } },
            dismissButton = { TextButton(onClick = { pendingCloudAction = "" }) { Text("لغو") } }
        )
    }
}

@Composable
fun ExplicitLocationShare(context: Context) {
    var message by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val ok = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (ok) shareLastLocation(context) { message = it } else message = "مجوز مکان داده نشد؛ هیچ اطلاعاتی ارسال نشد."
        pending = false
    }
    Button(onClick = {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (fine || coarse) shareLastLocation(context) { message = it }
        else { pending = true; permission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
    }, modifier = Modifier.fillMaxWidth()) { Text("اشتراک‌گذاری دستی موقعیت فعلی") }
    if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodySmall)
}

private fun shareLastLocation(context: Context, report: (String) -> Unit) {
    try {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) { report("مجوز مکان در دسترس نیست."); return }
        val candidates = listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
            .mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
        val loc = candidates.maxByOrNull { it.time }
        if (loc == null) { report("موقعیت قبلی در دسترس نیست؛ هیچ اطلاعاتی ارسال نشد."); return }
        val age = (System.currentTimeMillis() - loc.time).coerceAtLeast(0) / 60_000
        val link = "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        val text = "موقعیت انتخاب‌شدهٔ من: $link\nآخرین ثبت: $age دقیقه پیش. لطفاً تازگی موقعیت را بررسی کنید."
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, text)
        context.startActivity(android.content.Intent.createChooser(intent, "ارسال موقعیت" ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        report("برگهٔ اشتراک‌گذاری باز شد؛ ارسال فقط با انتخاب گیرنده و تأیید خودت انجام می‌شود.")
    } catch (e: Exception) { report(e.localizedMessage ?: "دریافت موقعیت ممکن نشد.") }
}
