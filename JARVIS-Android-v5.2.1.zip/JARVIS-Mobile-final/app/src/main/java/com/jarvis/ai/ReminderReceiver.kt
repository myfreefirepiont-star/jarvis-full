package com.jarvis.ai

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "J.A.R.V.I.S. reminder"
        val id = intent.getIntExtra("reminder_id", -1)
        if (id >= 0) ReminderStore.remove(context, id)
        val channel = "jarvis_reminders"
        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channel, "JARVIS reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("J.A.R.V.I.S.")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(if (id >= 0) id else (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification) }
        catch (_: SecurityException) { }
    }
}

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        ReminderStore.all(context).forEach { item ->
            if (item.second > System.currentTimeMillis()) ReminderStore.schedule(context, item.first, item.second, item.third)
            else ReminderStore.remove(context, item.first)
        }
    }
}

object ReminderStore {
    private const val PREFS = "jarvis_scheduled_reminders"
    private const val KEY = "items"
    data class Entry(val id: Int, val title: String, val at: Long)

    fun add(context: Context, title: String, at: Long): Int {
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt().let { if (it == 0) 1 else it }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(KEY, "[]") ?: "[]") }.getOrElse { JSONArray() }
        arr.put(JSONObject().put("id", id).put("title", title).put("at", at))
        prefs.edit().putString(KEY, arr.toString()).apply()
        schedule(context, id, title, at)
        return id
    }

    fun all(context: Context): List<Triple<Int, String, Long>> {
        val arr = runCatching { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]") }.getOrElse { JSONArray() }
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { arr.getJSONObject(i).let { Triple(it.getInt("id"), it.getString("title"), it.getLong("at")) } }.getOrNull()
        }
    }

    fun remove(context: Context, id: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = runCatching { JSONArray(prefs.getString(KEY, "[]") ?: "[]") }.getOrElse { JSONArray() }
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val obj = old.optJSONObject(i) ?: continue
            if (obj.optInt("id") != id) next.put(obj)
        }
        prefs.edit().putString(KEY, next.toString()).apply()
    }

    fun schedule(context: Context, id: Int, title: String, at: Long) {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", title).putExtra("reminder_id", id)
        val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
            else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pending)
    }
}
