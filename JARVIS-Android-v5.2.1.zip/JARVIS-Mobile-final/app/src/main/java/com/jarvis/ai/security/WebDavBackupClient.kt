package com.jarvis.ai.security

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/** Manual encrypted backup transfer to a user-owned HTTPS WebDAV endpoint. */
class WebDavBackupClient {
    private val client = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    private fun request(url: String, username: String, password: String): Request.Builder {
        require(url.startsWith("https://") && url.length < 2048) { "WebDAV address must use HTTPS." }
        require(username.isNotBlank()) { "WebDAV username is required." }
        val auth = Base64.encodeToString("$username:$password".toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        return Request.Builder().url(url).header("Authorization", "Basic $auth")
    }

    fun upload(url: String, username: String, password: String, encryptedBackup: ByteArray) {
        val req = request(url, username, password)
            .put(encryptedBackup.toRequestBody("application/octet-stream".toMediaType())).build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("WebDAV upload failed: HTTP ${response.code}")
        }
    }

    fun download(url: String, username: String, password: String): ByteArray {
        val req = request(url, username, password).get().build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("WebDAV download failed: HTTP ${response.code}")
            return response.body?.bytes() ?: throw IllegalStateException("Empty backup response")
        }
    }
}
