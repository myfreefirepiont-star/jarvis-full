package com.jarvis.ai.security

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Password-based portable AES-256-GCM backup. The passphrase is never stored. */
object EncryptedBackup {
    private val random = SecureRandom()
    private val magic = "JARVISBK1".toByteArray(Charsets.US_ASCII)
    private fun key(passphrase: CharArray, salt: ByteArray): SecretKeySpec {
        require(passphrase.size >= 10) { "گذرواژهٔ پشتیبان باید حداقل ۱۰ نویسه باشد." }
        val spec = PBEKeySpec(passphrase, salt, 210_000, 256)
        return try { SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES") }
        finally { spec.clearPassword() }
    }
    fun encrypt(plain: ByteArray, passphrase: CharArray): ByteArray {
        val salt = ByteArray(16).also(random::nextBytes)
        val iv = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(passphrase, salt), GCMParameterSpec(128, iv))
        return magic + salt + iv + cipher.doFinal(plain)
    }
    fun decrypt(packed: ByteArray, passphrase: CharArray): ByteArray {
        require(packed.size > magic.size + 16 + 12 + 16 && packed.copyOfRange(0, magic.size).contentEquals(magic)) { "فایل پشتیبان معتبر نیست." }
        val salt = packed.copyOfRange(magic.size, magic.size + 16)
        val iv = packed.copyOfRange(magic.size + 16, magic.size + 28)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(passphrase, salt), GCMParameterSpec(128, iv))
        return cipher.doFinal(packed.copyOfRange(magic.size + 28, packed.size))
    }
}
