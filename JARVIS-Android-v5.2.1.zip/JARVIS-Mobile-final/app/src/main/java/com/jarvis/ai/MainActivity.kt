package com.jarvis.ai

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Base64
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ai.ai.AiClient
import com.jarvis.ai.ai.AiConfig
import com.jarvis.ai.data.*
import com.jarvis.ai.security.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Bg = Color(0xFF080B13)
private val SurfaceDark = Color(0xFF121B2B)
private val Gold = Color(0xFFE9B95E)
private val Cyan = Color(0xFF55D9E8)
private val Purple = Color(0xFF9B82F5)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("fa", "IR") }
        setContent { JarvisRoot(onSpeak = { text ->
            val isPersian = text.any { it in '\u0600'..'\u06FF' }
            val locale = if (isPersian) Locale("fa", "IR") else Locale.US
            if (tts?.isLanguageAvailable(locale) == TextToSpeech.LANG_MISSING_DATA || tts?.isLanguageAvailable(locale) == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            } else tts?.language = locale
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }, onStop = { tts?.stop() }) }
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

private val LocalEnglish = staticCompositionLocalOf { false }
@Composable private fun tx(fa: String, en: String): String = if (LocalEnglish.current) en else fa

private enum class Tab { HOME, CHAT, VISION, LIVE_CAMERA, WEB, PLANNER, BACKUP, NOTES, TASKS, MEMORY, VAULT, APPS, NEWS, PRIVACY, UTILITIES, DEVICE, SAFETY, ROUTINE, MODES, COMMUNICATIONS, CALENDAR, VIDEO, CALLS, MODULES, JOURNEY, SETTINGS }

@Composable
private fun JarvisRoot(onSpeak: (String) -> Unit, onStop: () -> Unit) {
    val context = LocalContext.current
    val db = remember { JarvisDatabase.get(context) }
    val dao = db.dao()
    val scope = rememberCoroutineScope()
    val store = remember { SecureStore(context) }
    val ai = remember { AiClient() }
    val notes by dao.notes().collectAsState(initial = emptyList())
    val tasks by dao.tasks().collectAsState(initial = emptyList())
    val chat by dao.chat().collectAsState(initial = emptyList())
    val memories by dao.memories().collectAsState(initial = emptyList())
    val vaultItems by dao.vaultItems().collectAsState(initial = emptyList())
    val prefs = remember { context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var activeMode by remember { mutableStateOf(prefs.getString("active_mode", "Normal") ?: "Normal") }
    var baseUrl by remember { mutableStateOf(prefs.getString("base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1") }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini") }
    var apiKey by remember { mutableStateOf(store.read()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("آماده به کار") }
    var message by remember { mutableStateOf("") }
    var noteTitle by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    var taskTitle by remember { mutableStateOf("") }
    var taskDetail by remember { mutableStateOf("") }
    var taskPriority by remember { mutableFloatStateOf(1f) }
    var taskDueDays by remember { mutableStateOf("0") }
    var reminderTitle by remember { mutableStateOf("") }
    var reminderMinutes by remember { mutableStateOf("30") }
    var showAddNote by remember { mutableStateOf(false) }
    var showAddTask by remember { mutableStateOf(false) }
    var showReminder by remember { mutableStateOf(false) }
    var visionUri by remember { mutableStateOf<Uri?>(null) }
    var visionQuestion by remember { mutableStateOf("") }
    var ocrText by remember { mutableStateOf("") }
    var safetyContact by remember { mutableStateOf(prefs.getString("safety_contact", "") ?: "") }
    var pendingReminder by remember { mutableStateOf<Pair<String, Long>?>(null) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val pending = pendingReminder
        if (granted && pending != null) scheduleReminder(context, pending.first, pending.second)
        status = if (granted) if (english) "Reminder scheduled" else "یادآور تنظیم شد" else if (english) "Notifications permission denied" else "مجوز اعلان داده نشد"
        pendingReminder = null
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> visionUri = uri }
    var backupPassword by remember { mutableStateOf("") }
    val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            try {
                val encrypted = createEncryptedBackup(dao, backupPassword)
                context.contentResolver.openOutputStream(uri)?.use { it.write(encrypted) } ?: error("فایل مقصد باز نشد")
                status = if (english) "Encrypted backup saved" else "پشتیبان رمزگذاری‌شده ذخیره شد"
            } catch (e: Exception) { status = e.localizedMessage ?: "Backup failed" }
        }
    }
    val backupImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val packed = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("فایل خوانده نشد")
                restoreEncryptedBackup(dao, packed, backupPassword)
                status = if (english) "Backup restored; existing records were preserved" else "پشتیبان بازیابی شد؛ اطلاعات قبلی حفظ شدند"
            } catch (e: Exception) { status = e.localizedMessage ?: "Restore failed" }
        }
    }
    val vaultPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scope.launch {
                val name = runCatching { context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: uri.lastPathSegment ?: "Saved file"
                dao.addVaultItem(VaultEntity(title = name, uri = uri.toString(), mimeType = context.contentResolver.getType(uri).orEmpty()))
                status = if (english) "Saved to Knowledge Vault" else "در خزانه دانش ذخیره شد"
            }
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) message = spoken
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (english) "en-US" else "fa-IR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (english) "Speak to JARVIS" else "با جارویس صحبت کنید")
            }
            try { speechLauncher.launch(intent) } catch (_: Exception) { status = if (english) "Speech recognition is unavailable on this device." else "تشخیص گفتار در این دستگاه در دسترس نیست." }
        } else status = if (english) "Microphone permission denied." else "مجوز میکروفون داده نشد."
    }

    fun sendMessage() {
        val text = message.trim()
        if (text.isEmpty() || busy) return
        message = ""
        val localAnswer = OfflineCommandEngine.answer(text)
        if (localAnswer != null) {
            scope.launch { dao.addChat(ChatEntity(content = text, fromUser = true)); dao.addChat(ChatEntity(content = localAnswer, fromUser = false)) }
            status = if (english) "Offline response" else "پاسخ آفلاین"
            onSpeak(localAnswer)
            return
        }
        scope.launch {
            dao.addChat(ChatEntity(content = text, fromUser = true))
            busy = true; status = if (english) "Processing" else "در حال پردازش"
            try {
                val history = (chat.map { it.fromUser to it.content } + listOf(true to text))
                val answer = withContext(Dispatchers.IO) { ai.ask(AiConfig(baseUrl, model, store.read()), history, memories.map { "[${it.category}] ${it.content}" } + listOf("[Active mode] $activeMode")) }
                dao.addChat(ChatEntity(content = answer, fromUser = false))
                status = if (english) "Ready" else "پاسخ آماده"
                onSpeak(answer)
            } catch (e: Exception) {
                val err = e.message ?: "خطای نامشخص"
                dao.addChat(ChatEntity(content = if (english) "AI connection failed: $err\n\nLocal features remain available." else "اتصال به هوش مصنوعی ناموفق بود: $err\n\nقابلیت‌های محلی همچنان در دسترس‌اند.", fromUser = false))
                status = if (english) "Connection error" else "خطا در اتصال"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = Cyan, background = Bg, surface = SurfaceDark)) {
      CompositionLocalProvider(LocalEnglish provides english, LocalLayoutDirection provides if (english) LayoutDirection.Ltr else LayoutDirection.Rtl) {
        Scaffold(containerColor = Bg, bottomBar = {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(Color(0xFF0D1421)).padding(horizontal = 4.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Tab.values().forEach { item ->
                    val title = when(item) { Tab.HOME -> tx("خانه","Home"); Tab.CHAT -> tx("دستیار","Assistant"); Tab.VISION -> tx("بینایی","Vision"); Tab.LIVE_CAMERA -> tx("دوربین زنده","Live cam"); Tab.WEB -> tx("وب","Web"); Tab.PLANNER -> tx("برنامه‌ریز","Planner"); Tab.BACKUP -> tx("پشتیبان","Backup"); Tab.NOTES -> tx("یادداشت","Notes"); Tab.TASKS -> tx("وظایف","Tasks"); Tab.MEMORY -> tx("حافظه","Memory"); Tab.VAULT -> tx("خزانه","Vault"); Tab.APPS -> tx("برنامه‌ها","Apps"); Tab.NEWS -> tx("اخبار","News"); Tab.PRIVACY -> tx("حریم خصوصی","Privacy"); Tab.UTILITIES -> tx("ابزارها","Tools"); Tab.DEVICE -> tx("دستگاه","Device"); Tab.SAFETY -> tx("ایمنی","Safety"); Tab.ROUTINE -> tx("روال روزانه","Routine"); Tab.MODES -> tx("حالت‌ها","Modes"); Tab.COMMUNICATIONS -> tx("ارتباطات","Comms"); Tab.CALENDAR -> tx("تقویم","Calendar"); Tab.VIDEO -> tx("ویدیو","Video"); Tab.CALLS -> tx("تماس","Calls"); Tab.MODULES -> tx("ماژول‌ها","Modules"); Tab.JOURNEY -> tx("سفر امن","Safe trip"); Tab.SETTINGS -> tx("تنظیمات","Settings") }
                    val icon = when(item) { Tab.HOME -> Icons.Default.Home; Tab.CHAT -> Icons.Default.Forum; Tab.VISION -> Icons.Default.Visibility; Tab.LIVE_CAMERA -> Icons.Default.CameraAlt; Tab.WEB -> Icons.Default.Language; Tab.PLANNER -> Icons.Default.AccountTree; Tab.BACKUP -> Icons.Default.Backup; Tab.NOTES -> Icons.Default.StickyNote2; Tab.TASKS -> Icons.Default.CheckCircle; Tab.MEMORY -> Icons.Default.Psychology; Tab.VAULT -> Icons.Default.Folder; Tab.APPS -> Icons.Default.Apps; Tab.NEWS -> Icons.Default.Newspaper; Tab.PRIVACY -> Icons.Default.PrivacyTip; Tab.UTILITIES -> Icons.Default.Calculate; Tab.DEVICE -> Icons.Default.PhoneAndroid; Tab.SAFETY -> Icons.Default.Security; Tab.ROUTINE -> Icons.Default.WbSunny; Tab.MODES -> Icons.Default.Tune; Tab.COMMUNICATIONS -> Icons.Default.Message; Tab.CALENDAR -> Icons.Default.Event; Tab.VIDEO -> Icons.Default.VideoLibrary; Tab.CALLS -> Icons.Default.PhoneInTalk; Tab.MODULES -> Icons.Default.Extension; Tab.JOURNEY -> Icons.Default.Route; Tab.SETTINGS -> Icons.Default.Settings }
                    Column(Modifier.width(68.dp).clickable { tab = item }.padding(vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(icon, contentDescription = title, tint = if (tab == item) Gold else Color.Gray)
                        Text(title, color = if (tab == item) Gold else Color.Gray, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("J.A.R.V.I.S.", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text(tx("سامانه هوشمند شخصی", "PERSONAL INTELLIGENCE SYSTEM"), color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        TextButton(onClick = { english = !english; prefs.edit().putBoolean("english", english).apply() }) { Text(if (english) "فارسی" else "English", color = Gold, fontSize = 11.sp) }
                        Surface(color = Color(0xFF17283A), shape = CircleShape) {
                            Text(status, color = Cyan, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontSize = 10.sp)
                        }
                    }
                }
                when (tab) {
                    Tab.HOME -> HomeScreen(notes.size, tasks.count { !it.done }, onChat = { tab = Tab.CHAT }, onNotes = { tab = Tab.NOTES }, onTasks = { tab = Tab.TASKS }, onReminder = { showReminder = true }, onVision = { tab = Tab.VISION }, onDevice = { tab = Tab.DEVICE }, onUtilities = { tab = Tab.UTILITIES }, onSafety = { tab = Tab.SAFETY }, onWeb = { tab = Tab.WEB })
                    Tab.CHAT -> ChatScreen(chat, message, { message = it }, busy, { sendMessage() }, {
                        onStop()
                    }, {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }, onClear = { scope.launch { dao.clearChat() } })
                    Tab.VISION -> VisionScreen(visionUri, visionQuestion, { visionQuestion = it }, { imagePicker.launch("image/*") }, { uri ->
                        scope.launch {
                            busy = true; status = if (english) "Analyzing image" else "در حال تحلیل تصویر"
                            try {
                                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error(if (english) "Could not read image" else "خواندن تصویر ناموفق بود")
                                require(bytes.size <= 8 * 1024 * 1024) { if (english) "Image must be smaller than 8 MB" else "حجم تصویر باید کمتر از ۸ مگابایت باشد" }
                                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                                val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                                val answer = withContext(Dispatchers.IO) { ai.askWithImage(AiConfig(baseUrl, model, store.read()), emptyList(), encoded, mime, visionQuestion.ifBlank { if (english) "Describe and analyze this image." else "این تصویر را توصیف و تحلیل کن." }) }
                                dao.addChat(ChatEntity(content = answer, fromUser = false)); tab = Tab.CHAT; status = if (english) "Analysis complete" else "تحلیل کامل شد"
                            } catch (e: Exception) { status = e.message ?: if (english) "Image analysis failed" else "خطا در تحلیل تصویر" }
                            finally { busy = false }
                        }
                    })
                    Tab.LIVE_CAMERA -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LiveCameraOcr(onOcr = { text -> ocrText = text; status = if (english) "OCR complete" else "استخراج متن کامل شد" })
                        if (ocrText.isNotBlank()) { Text("متن استخراج‌شده:", color = Gold); Text(ocrText, color = Color.White); OutlinedButton(onClick = { message = "این متن را تحلیل کن و نکات مهمش را بگو:\n$ocrText"; tab = Tab.CHAT }) { Text("ارسال متن به دستیار") } }
                    }
                    Tab.WEB -> EmbeddedWebResearch(onSummarize = { page ->
                        scope.launch {
                            busy = true; status = if (english) "Summarizing page" else "در حال خلاصه‌سازی صفحه"
                            try {
                                val answer = withContext(Dispatchers.IO) { ai.ask(AiConfig(baseUrl, model, store.read()), listOf(true to "Summarize this webpage in the user's language. Distinguish facts from opinions and mention that the text was extracted from the currently opened page:\n\n${page.take(20000)}")) }
                                dao.addChat(ChatEntity(content = "خلاصهٔ صفحه:\n$answer", fromUser = false)); tab = Tab.CHAT; status = if (english) "Page summarized" else "صفحه خلاصه شد"
                            } catch (e: Exception) { status = e.localizedMessage ?: "خلاصه‌سازی ناموفق بود" } finally { busy = false }
                        }
                    })
                    Tab.PLANNER -> PlannerScreen(onExecute = { actions ->
                        scope.launch {
                            actions.forEach { action -> when(action.type) {
                                "note" -> dao.addNote(NoteEntity(title = action.detail.take(70), body = action.detail))
                                "task" -> dao.addTask(TaskEntity(title = action.detail.take(100), detail = action.detail))
                                "reminder" -> {
                                    val title = action.detail.take(120)
                                    val delay = reminderDelayMillis(action.detail)
                                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                        pendingReminder = title to delay
                                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else scheduleReminder(context, title, delay)
                                }
                            } }
                            status = if (english) "Approved local plan executed" else "برنامهٔ تأییدشده اجرا شد"
                        }
                    })
                    Tab.BACKUP -> EncryptedBackupScreen(
                        onExport = { pass -> backupPassword = pass; backupExport.launch("jarvis-backup-${System.currentTimeMillis()}.jvb") },
                        onImport = { pass -> backupPassword = pass; backupImport.launch(arrayOf("application/octet-stream", "application/*", "*/*")) },
                        onCloudUpload = { endpoint, user, cloudPass, backupPass ->
                            scope.launch {
                                try {
                                    val encrypted = createEncryptedBackup(dao, backupPass)
                                    withContext(Dispatchers.IO) { com.jarvis.ai.security.WebDavBackupClient().upload(endpoint, user, cloudPass, encrypted) }
                                    status = if (english) "Encrypted cloud backup uploaded" else "پشتیبان رمزگذاری‌شده در فضای ابری بارگذاری شد"
                                } catch (e: Exception) { status = e.localizedMessage ?: "Cloud upload failed" }
                            }
                        },
                        onCloudDownload = { endpoint, user, cloudPass, backupPass ->
                            scope.launch {
                                try {
                                    val encrypted = withContext(Dispatchers.IO) { com.jarvis.ai.security.WebDavBackupClient().download(endpoint, user, cloudPass) }
                                    restoreEncryptedBackup(dao, encrypted, backupPass)
                                    status = if (english) "Cloud backup restored" else "پشتیبان ابری بازیابی شد"
                                } catch (e: Exception) { status = e.localizedMessage ?: "Cloud restore failed" }
                            }
                        }
                    )
                    Tab.NOTES -> NotesScreen(notes, onAdd = { showAddNote = true }, onDelete = { scope.launch { dao.deleteNote(it) } }, onUpdate = { scope.launch { dao.updateNote(it.copy(updatedAt = System.currentTimeMillis())) } })
                    Tab.TASKS -> TasksScreen(tasks, onAdd = { showAddTask = true }, onToggle = { scope.launch { dao.updateTask(it.copy(done = !it.done)) } }, onDelete = { scope.launch { dao.deleteTask(it) } }, onReminder = { showReminder = true })
                    Tab.MEMORY -> MemoryScreen(memories, onAdd = { content, category -> scope.launch { dao.addMemory(MemoryEntity(category = category, content = content)) } }, onDelete = { item -> scope.launch { dao.deleteMemory(item) } }, onClear = { scope.launch { dao.clearMemory() } })
                    Tab.VAULT -> VaultScreen(vaultItems, onAdd = { vaultPicker.launch(arrayOf("*/*")) }, onDelete = { item -> scope.launch { runCatching { context.contentResolver.releasePersistableUriPermission(Uri.parse(item.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) }; dao.deleteVaultItem(item) } }, onOpen = { item -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.uri), item.mimeType.ifBlank { "*/*" }).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } })
                    Tab.APPS -> AppLauncherScreen()
                    Tab.NEWS -> NewsScreen()
                    Tab.PRIVACY -> PrivacyScreen(context, onClearChat = { scope.launch { dao.clearChat() } }, onClearMemory = { scope.launch { dao.clearMemory() } })
                    Tab.UTILITIES -> UtilitiesScreen(onReminder = { title, minutes -> scheduleReminder(context, title, minutes * 60_000L); status = if (english) "Timer scheduled" else "تایمر تنظیم شد" }, onClipboard = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = clipboard.primaryClip
                        val copied = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(context)?.toString().orEmpty() else ""
                        if (copied.isNotBlank()) { message = copied; tab = Tab.CHAT; status = if (english) "Clipboard text ready" else "متن کلیپ‌بورد آماده است" } else status = if (english) "Clipboard is empty" else "کلیپ‌بورد خالی است"
                    })
                    Tab.DEVICE -> DeviceScreen(context, onOpenSettings = { runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } })
                    Tab.SAFETY -> SafetyScreen(safetyContact, { safetyContact = it; prefs.edit().putString("safety_contact", it).apply() }, onDial = { number -> runCatching { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))) } })
                    Tab.ROUTINE -> RoutineScreen(context, tasks.count { !it.done }, notes.size, onSchedule = { title, at -> ReminderStore.add(context, title, at); status = if (english) "One-time briefing reminder scheduled" else "یادآور یک‌بارهٔ برنامه‌ریزی شد" })
                    Tab.MODES -> ModesScreen(activeMode, onSelect = { activeMode = it; prefs.edit().putString("active_mode", it).apply(); status = if (english) "Mode changed" else "حالت تغییر کرد" })
                    Tab.COMMUNICATIONS -> CommunicationsScreen()
                    Tab.CALENDAR -> CalendarScreen()
                    Tab.VIDEO -> VideoModuleScreen()
                    Tab.CALLS -> CallReceptionScreen()
                    Tab.MODULES -> ModulesScreen()
                    Tab.JOURNEY -> JourneyScreen(context)
                    Tab.SETTINGS -> SettingsScreen(baseUrl, { baseUrl = it; prefs.edit().putString("base_url", it).apply() }, model, { model = it; prefs.edit().putString("model", it).apply() }, apiKey, {
                        apiKey = it; store.save(it)
                    }, onTest = {
                        scope.launch {
                            busy = true
                            try {
                                val response = withContext(Dispatchers.IO) { ai.ask(AiConfig(baseUrl, model, store.read()), listOf(true to if (english) "Reply only: Connection established." else "فقط بنویس: اتصال برقرار است.")) }
                                status = if (english) "Connection successful" else "اتصال موفق"
                            } catch (e: Exception) { status = if (english) "Connection failed: ${e.message ?: "Error"}" else "اتصال ناموفق: ${e.message ?: "خطا"}" }
                            finally { busy = false }
                        }
                    }, busy)
                }
            }
        }
      }
    }

    if (showAddNote) AlertDialog(onDismissRequest = { showAddNote = false }, title = { Text(tx("یادداشت جدید", "New note")) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(noteTitle, { noteTitle = it }, label = { Text(tx("عنوان", "Title")) }, singleLine = true)
            OutlinedTextField(noteBody, { noteBody = it }, label = { Text(tx("متن یادداشت", "Note text")) }, minLines = 3)
        } }, confirmButton = { TextButton(onClick = {
            if (noteTitle.isNotBlank() || noteBody.isNotBlank()) scope.launch { dao.addNote(NoteEntity(title = noteTitle.ifBlank { if (english) "Untitled note" else "یادداشت بدون عنوان" }, body = noteBody)) }
            noteTitle = ""; noteBody = ""; showAddNote = false
        }) { Text(tx("ذخیره", "Save")) } }, dismissButton = { TextButton(onClick = { showAddNote = false }) { Text(tx("لغو", "Cancel")) } })

    if (showAddTask) AlertDialog(onDismissRequest = { showAddTask = false }, title = { Text(tx("وظیفه جدید", "New task")) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(taskTitle, { taskTitle = it }, label = { Text(tx("عنوان وظیفه", "Task title")) })
            OutlinedTextField(taskDetail, { taskDetail = it }, label = { Text(tx("جزئیات (اختیاری)", "Details (optional)")) })
            Text(tx("اولویت: ${taskPriority.toInt()}", "Priority: ${taskPriority.toInt()}"), color = Gold)
            Slider(value = taskPriority, onValueChange = { taskPriority = it }, valueRange = 1f..3f, steps = 1)
            OutlinedTextField(taskDueDays, { taskDueDays = it.filter(Char::isDigit).take(4) }, label = { Text(tx("سررسید چند روز دیگر؟ (۰ = بدون سررسید)", "Due in how many days? (0 = none)")) }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = {
            val days = taskDueDays.toLongOrNull()?.coerceIn(0, 3650) ?: 0L
            val due = if (days > 0) System.currentTimeMillis() + days * 86_400_000L else null
            if (taskTitle.isNotBlank()) scope.launch { dao.addTask(TaskEntity(title = taskTitle, detail = taskDetail, priority = taskPriority.toInt(), dueAt = due)) }
            taskTitle = ""; taskDetail = ""; taskPriority = 1f; taskDueDays = "0"; showAddTask = false
        }) { Text(tx("افزودن", "Add")) } }, dismissButton = { TextButton(onClick = { showAddTask = false }) { Text(tx("لغو", "Cancel")) } })

    if (showReminder) AlertDialog(onDismissRequest = { showReminder = false }, title = { Text(tx("تنظیم یادآور", "Set reminder")) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(reminderTitle, { reminderTitle = it }, label = { Text(tx("متن یادآور", "Reminder text")) })
            OutlinedTextField(reminderMinutes, { reminderMinutes = it.filter(Char::isDigit) }, label = { Text(tx("چند دقیقه دیگر؟", "In how many minutes?")) })
        } }, confirmButton = { TextButton(onClick = {
            val mins = reminderMinutes.toLongOrNull()?.coerceIn(1, 10080) ?: 30
            val title = reminderTitle.ifBlank { if (english) "It's time for your task." else "زمان انجام کار فرا رسیده است." }
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                pendingReminder = title to (mins * 60_000L)
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else scheduleReminder(context, title, mins * 60_000L)
            reminderTitle = ""; showReminder = false; status = if (english) "Reminder scheduled" else "یادآور تنظیم شد"
        }) { Text(tx("تنظیم", "Schedule")) } }, dismissButton = { TextButton(onClick = { showReminder = false }) { Text(tx("لغو", "Cancel")) } })
}

private suspend fun createEncryptedBackup(dao: JarvisDao, passphrase: String): ByteArray {
    val root = org.json.JSONObject().put("format", "jarvis-backup-v1")
    val ns = org.json.JSONArray(); dao.allNotes().forEach { ns.put(org.json.JSONObject().put("title",it.title).put("body",it.body).put("updatedAt",it.updatedAt)) }; root.put("notes",ns)
    val ts = org.json.JSONArray(); dao.allTasks().forEach { ts.put(org.json.JSONObject().put("title",it.title).put("detail",it.detail).put("done",it.done).put("priority",it.priority).put("dueAt",it.dueAt ?: org.json.JSONObject.NULL).put("createdAt",it.createdAt)) }; root.put("tasks",ts)
    val ms = org.json.JSONArray(); dao.allMemories().forEach { ms.put(org.json.JSONObject().put("category",it.category).put("content",it.content).put("createdAt",it.createdAt)) }; root.put("memories",ms)
    val cs = org.json.JSONArray(); dao.allChat().takeLast(1000).forEach { cs.put(org.json.JSONObject().put("content",it.content).put("fromUser",it.fromUser).put("createdAt",it.createdAt)) }; root.put("chat",cs)
    return com.jarvis.ai.security.EncryptedBackup.encrypt(root.toString().toByteArray(Charsets.UTF_8), passphrase.toCharArray())
}

private suspend fun restoreEncryptedBackup(dao: JarvisDao, packed: ByteArray, passphrase: String) {
    val root = org.json.JSONObject(String(com.jarvis.ai.security.EncryptedBackup.decrypt(packed, passphrase.toCharArray()), Charsets.UTF_8))
    require(root.optString("format") == "jarvis-backup-v1") { "نسخهٔ فایل پشتیبان پشتیبانی نمی‌شود." }
    val ns = mutableListOf<NoteEntity>(); val na = root.optJSONArray("notes") ?: org.json.JSONArray()
    for (i in 0 until na.length()) { val o=na.getJSONObject(i); ns += NoteEntity(title=o.optString("title"), body=o.optString("body"), updatedAt=o.optLong("updatedAt")) }
    val ts = mutableListOf<TaskEntity>(); val ta = root.optJSONArray("tasks") ?: org.json.JSONArray()
    for (i in 0 until ta.length()) { val o=ta.getJSONObject(i); ts += TaskEntity(title=o.optString("title"), detail=o.optString("detail"), done=o.optBoolean("done"), priority=o.optInt("priority",1), dueAt=if(o.isNull("dueAt")) null else o.optLong("dueAt"), createdAt=o.optLong("createdAt")) }
    val ms = mutableListOf<MemoryEntity>(); val ma = root.optJSONArray("memories") ?: org.json.JSONArray()
    for (i in 0 until ma.length()) { val o=ma.getJSONObject(i); ms += MemoryEntity(category=o.optString("category"), content=o.optString("content"), createdAt=o.optLong("createdAt")) }
    val cs = mutableListOf<ChatEntity>(); val ca = root.optJSONArray("chat") ?: org.json.JSONArray()
    for (i in 0 until ca.length()) { val o=ca.getJSONObject(i); cs += ChatEntity(content=o.optString("content"), fromUser=o.optBoolean("fromUser"), createdAt=o.optLong("createdAt")) }
    dao.importNotes(ns); dao.importTasks(ts); dao.importMemories(ms); dao.importChat(cs)
}

private fun scheduleReminder(context: Context, title: String, delay: Long) {
    ReminderStore.add(context, title, System.currentTimeMillis() + delay)
}

@Composable
private fun HomeScreen(noteCount: Int, taskCount: Int, onChat: () -> Unit, onNotes: () -> Unit, onTasks: () -> Unit, onReminder: () -> Unit, onVision: () -> Unit, onDevice: () -> Unit, onUtilities: () -> Unit, onSafety: () -> Unit, onWeb: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(176.dp).background(Brush.radialGradient(listOf(Color(0x6642D7E8), Color(0x229B82F5), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(118.dp).background(Color(0x222BBFD5), CircleShape), contentAlignment = Alignment.Center) {
                Text("J", color = Gold, fontSize = 68.sp, fontWeight = FontWeight.Light)
            }
        }
        Text(tx("سیستم آماده است", "SYSTEM READY"), color = Cyan, fontSize = 13.sp)
        Text(tx("دستیار هوشمند شخصی شما", "Your Personal AI Assistant"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        Text(tx("برای گفتگو وارد بخش دستیار شوید.", "Open Assistant to start a conversation."), color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            MetricCard(tx("یادداشت‌ها", "Notes"), noteCount.toString(), Icons.Default.StickyNote2, Modifier.weight(1f), onNotes)
            MetricCard(tx("وظایف باز", "Open tasks"), taskCount.toString(), Icons.Default.CheckCircle, Modifier.weight(1f), onTasks)
        }
        Spacer(Modifier.height(12.dp))
        ActionCard(tx("شروع گفتگو", "Start conversation"), tx("پرسش، ایده یا فرمان خود را مطرح کنید", "Ask a question or give a command"), Icons.Default.Forum, onChat)
        ActionCard(tx("تحلیل تصویر", "Analyze image"), tx("تصویر انتخابی را با مدل بینایی تحلیل کن", "Analyze a selected image with a vision model"), Icons.Default.Visibility, onVision)
        ActionCard(tx("جست‌وجوی وب", "Web search"), tx("جست‌وجوی زنده در مرورگر دستگاه", "Open a live search in your browser"), Icons.Default.Language, onWeb)
        ActionCard(tx("ابزارهای کاربردی", "Utilities"), tx("ماشین‌حساب آفلاین، تایمر و کلیپ‌بورد", "Offline calculator, timer and clipboard"), Icons.Default.Calculate, onUtilities)
        ActionCard(tx("وضعیت دستگاه", "Device status"), tx("باتری، شبکه و اطلاعات سیستم", "Battery, network and system information"), Icons.Default.PhoneAndroid, onDevice)
        ActionCard(tx("مرکز ایمنی", "Safety center"), tx("مخاطب اضطراری و شماره‌گیری سریع", "Emergency contact and quick dial"), Icons.Default.Security, onSafety)
        ActionCard(tx("یادآور سریع", "Quick reminder"), tx("برای یک کار زمان مشخص کن", "Schedule a reminder"), Icons.Default.Alarm, onReminder)
        Spacer(Modifier.weight(1f))
        Text(tx("نسخه 5.1.0 • امکانات دستگاه تابع مجوزها و نسخه اندروید است", "Version 5.1.0 • Device features depend on permissions and Android version"), color = Color.Gray, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(bottom = 14.dp))
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, click: () -> Unit) {
    Surface(modifier.clickable { click() }, color = SurfaceDark, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, null, tint = Cyan)
            Text(value, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Color.LightGray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { click() }, color = SurfaceDark, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(28.dp))
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Color.Gray, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Cyan)
        }
    }
}

@Composable
private fun ChatScreen(chat: List<ChatEntity>, message: String, onMessage: (String) -> Unit, busy: Boolean, onSend: () -> Unit, onStop: () -> Unit, onMic: () -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(tx("گفت‌وگو با جارویس", "Chat with JARVIS"), color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear) { Text(tx("پاک‌کردن تاریخچه", "Clear history"), color = Color.Gray, fontSize = 10.sp) }
            if (busy) TextButton(onClick = onStop) { Text(tx("توقف صدا", "Stop speech"), color = Gold) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(chat, key = { it.id }) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (line.fromUser) Color(0xFF273850) else SurfaceDark, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                        Text(line.content, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
                    }
                }
            }
            if (busy) item { Text(tx("جارویس در حال فکر کردن است…", "JARVIS is thinking…"), color = Cyan, fontSize = 11.sp) }
        }
        Row(Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(18.dp)).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, null, tint = Cyan) }
            BasicTextField(message, onMessage, Modifier.weight(1f).padding(8.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), decorationBox = { inner ->
                if (message.isEmpty()) Text(tx("پیامت را بنویس…", "Type your message…"), color = Color.Gray, fontSize = 13.sp)
                inner
            })
            IconButton(onClick = onSend, enabled = !busy) { Icon(Icons.Default.Send, null, tint = Gold) }
        }
        Text(tx("ارسال متن به سرویس API انتخاب‌شده انجام می‌شود.", "Messages are sent to your configured AI API provider."), color = Color.Gray, fontSize = 9.sp, modifier = Modifier.padding(5.dp))
    }
}

@Composable
private fun NotesScreen(notes: List<NoteEntity>, onAdd: () -> Unit, onDelete: (NoteEntity) -> Unit, onUpdate: (NoteEntity) -> Unit) {
    var editing by remember { mutableStateOf<NoteEntity?>(null) }
    var editTitle by remember { mutableStateOf("") }
    var editBody by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("دفترچه یادداشت", "Notes"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text(tx("یادداشت", "Note")) }
        }
        if (notes.isEmpty()) EmptyState(tx("هنوز یادداشتی ذخیره نشده است.", "No notes saved yet."))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(notes, key = { it.id }) { note ->
                Surface(color = SurfaceDark, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(note.title, color = Gold, fontWeight = FontWeight.SemiBold)
                            Text(note.body, color = Color.LightGray, fontSize = 12.sp, maxLines = 4)
                        }
                        IconButton(onClick = { editing = note; editTitle = note.title; editBody = note.body }) { Icon(Icons.Default.Edit, null, tint = Cyan) }
                        IconButton(onClick = { onDelete(note) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                    }
                }
            }
        }
    }
    editing?.let { note ->
        AlertDialog(onDismissRequest = { editing = null }, title = { Text(tx("ویرایش یادداشت", "Edit note")) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(editTitle, { editTitle = it }, label = { Text(tx("عنوان", "Title")) })
                OutlinedTextField(editBody, { editBody = it }, label = { Text(tx("متن", "Body")) }, minLines = 3)
            } },
            confirmButton = { TextButton(onClick = { onUpdate(note.copy(title = editTitle, body = editBody)); editing = null }) { Text(tx("ذخیره", "Save")) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(tx("لغو", "Cancel")) } })
    }
}

@Composable
private fun TasksScreen(tasks: List<TaskEntity>, onAdd: () -> Unit, onToggle: (TaskEntity) -> Unit, onDelete: (TaskEntity) -> Unit, onReminder: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("مدیریت وظایف", "Tasks"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = onReminder) { Icon(Icons.Default.AlarmAdd, null, tint = Cyan) }
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text(tx("وظیفه", "Task")) }
        }
        if (tasks.isEmpty()) EmptyState(tx("وظیفه‌ای ثبت نشده است.", "No tasks yet."))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { task ->
                Surface(color = SurfaceDark, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = { onToggle(task) })
                        Column(Modifier.weight(1f)) {
                            Text(task.title, color = if (task.done) Color.Gray else Color.White)
                            if (task.detail.isNotBlank()) Text(task.detail, color = Color.LightGray, fontSize = 10.sp)
                            Text(tx("اولویت ${task.priority}" + (task.dueAt?.let { " • سررسید ${java.text.DateFormat.getDateInstance().format(java.util.Date(it))}" } ?: ""), "Priority ${task.priority}" + (task.dueAt?.let { " • due ${java.text.DateFormat.getDateInstance().format(java.util.Date(it))}" } ?: "")), color = Gold, fontSize = 9.sp)
                        }
                        IconButton(onClick = { onDelete(task) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                    }
                }
            }
        }
    }
}

@Composable
private fun VisionScreen(uri: Uri?, question: String, onQuestion: (String) -> Unit, onPick: () -> Unit, onAnalyze: (Uri) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(tx("بینایی JARVIS", "JARVIS Vision"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("یک تصویر از گالری انتخاب کن. تصویر فقط پس از فشردن دکمه تحلیل به سرویس AI تنظیم‌شده ارسال می‌شود.", "Choose an image. It is sent to your configured AI provider only after you press Analyze."), color = Color.LightGray, fontSize = 12.sp)
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AddPhotoAlternate, null); Text(tx("انتخاب تصویر", "Choose image")) }
        if (uri != null) Text(tx("تصویر انتخاب شده است", "Image selected"), color = Cyan)
        OutlinedTextField(question, onQuestion, modifier = Modifier.fillMaxWidth(), label = { Text(tx("چه چیزی را بررسی کنم؟", "What should I examine?")) })
        Button(onClick = { uri?.let(onAnalyze) }, enabled = uri != null, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Visibility, null); Text(tx("تحلیل تصویر", "Analyze image")) }
        Text(tx("نیازمند مدل دارای قابلیت بینایی و API key است؛ ممکن است هزینه API داشته باشد.", "Requires a vision-capable model and API key; provider charges may apply."), color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun WebScreen() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(tx("جست‌وجوی اینترنت", "Internet search"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("جست‌وجو در مرورگر پیش‌فرض دستگاه باز می‌شود. نتایج و منابع را مستقیماً در وب بررسی کن.", "Search opens in your default browser. Review results and sources directly on the web."), color = Color.LightGray, fontSize = 12.sp)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("عبارت جست‌وجو", "Search query")) }, singleLine = true)
        Button(onClick = { if (query.isNotBlank()) runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))) } }, enabled = query.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Search, null); Text(tx("جست‌وجو با Google", "Search with Google")) }
        OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://news.google.com/"))) } }, modifier = Modifier.fillMaxWidth()) { Text(tx("باز کردن Google News", "Open Google News")) }
        Text(tx("این نسخه نتایج وب را داخل برنامه استخراج یا خلاصه نمی‌کند؛ مرورگر را به‌عنوان مسیر امن و شفاف استفاده می‌کند.", "This release does not scrape or summarize web pages in-app; it uses the browser as a transparent fallback."), color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun UtilitiesScreen(onReminder: (String, Long) -> Unit, onClipboard: () -> Unit) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var timerLabel by remember { mutableStateOf("") }
    var timerMinutes by remember { mutableStateOf("5") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(tx("ابزارهای آفلاین", "Offline utilities"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Surface(color = SurfaceDark, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tx("ماشین‌حساب", "Calculator"), color = Gold, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(expression, { expression = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("عبارت ریاضی", "Math expression")) }, singleLine = true)
                Button(onClick = { result = runCatching { JarvisCalculator.evaluate(expression).toString() }.getOrElse { it.message ?: "Error" } }, modifier = Modifier.fillMaxWidth()) { Text(tx("محاسبه", "Calculate")) }
                if (result.isNotBlank()) Text("= $result", color = Cyan, fontSize = 18.sp)
                Text(tx("عملگرهای پشتیبانی‌شده: + − × ÷ و پرانتز", "Supported operators: + − × ÷ and parentheses"), color = Color.Gray, fontSize = 10.sp)
            }
        }
        Surface(color = SurfaceDark, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tx("تایمر سریع", "Quick timer"), color = Gold, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(timerLabel, { timerLabel = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("عنوان تایمر", "Timer label")) }, singleLine = true)
                OutlinedTextField(timerMinutes, { timerMinutes = it.filter(Char::isDigit).take(5) }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("مدت به دقیقه", "Duration in minutes")) }, singleLine = true)
                Button(onClick = { val mins = timerMinutes.toLongOrNull()?.coerceIn(1, 10080) ?: 5L; onReminder(timerLabel.ifBlank { if (LocalEnglish.current) "Timer finished" else "زمان تایمر تمام شد" }, mins); timerLabel = "" }, modifier = Modifier.fillMaxWidth()) { Text(tx("شروع تایمر", "Start timer")) }
                Text(tx("اعلان‌ها باید در تنظیمات اندروید مجاز باشند.", "Notifications must be allowed in Android settings."), color = Color.Gray, fontSize = 10.sp)
            }
        }
        OutlinedButton(onClick = onClipboard, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(8.dp)); Text(tx("وارد کردن متن انتخابی از کلیپ‌بورد", "Import selected clipboard text")) }
        Text(tx("کلیپ‌بورد فقط با فشردن همین دکمه خوانده می‌شود؛ محتوای آن به‌صورت خودکار پایش نمی‌شود.", "Clipboard is read only when you press this button; it is never monitored continuously."), color = Color.Gray, fontSize = 10.sp)
    }
}

@Composable
private fun DeviceScreen(context: Context, onOpenSettings: () -> Unit) {
    val battery = remember { context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager }.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    val cm = remember { context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    val network = remember { cm.activeNetwork?.let { cm.getNetworkCapabilities(it) } }
    val online = network?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    val activityManager = remember { context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager }
    val memoryInfo = remember { android.app.ActivityManager.MemoryInfo().also(activityManager::getMemoryInfo) }
    val totalRamGb = memoryInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
    val freeStorageGb = remember {
        runCatching { android.os.StatFs(context.filesDir.absolutePath).availableBytes / (1024.0 * 1024.0 * 1024.0) }.getOrDefault(0.0)
    }
    val appVersion = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "Unknown" }.getOrDefault("Unknown")
    }
    val info = listOf(
        tx("باتری", "Battery") to if (battery >= 0) "$battery%" else tx("نامشخص", "Unknown"),
        tx("شبکه", "Network") to if (online) tx("اتصال شبکه موجود است", "Network available") else tx("آفلاین", "Offline"),
        tx("مدل دستگاه", "Device model") to "${Build.MANUFACTURER} ${Build.MODEL}",
        tx("شناسه سخت‌افزار", "Hardware") to "${Build.DEVICE} / ${Build.PRODUCT}",
        tx("نسخه اندروید", "Android version") to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        tx("حافظه RAM", "Total RAM") to String.format(java.util.Locale.US, "%.1f GB", totalRamGb),
        tx("فضای آزاد برنامه", "Available app storage") to String.format(java.util.Locale.US, "%.2f GB", freeStorageGb),
        tx("معماری پردازنده", "CPU ABI") to Build.SUPPORTED_ABIS.joinToString(", "),
        tx("برنامه", "App") to "J.A.R.V.I.S. $appVersion"
    )
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("داشبورد دستگاه", "Device dashboard"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("این اطلاعات برای انتخاب مدل آفلاین و بررسی سازگاری قابلیت‌های صوتی استفاده می‌شود؛ مدل دقیق سخت‌افزار از خود سیستم خوانده می‌شود.", "These diagnostics help assess offline-model and audio-feature compatibility; hardware identifiers are read directly from Android."), color = Color.LightGray, fontSize = 11.sp)
        info.forEach { (k,v) -> Surface(color = SurfaceDark, shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(k, color = Cyan); Text(v, color = Color.White) } } }
        Button(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Settings, null); Text(tx("تنظیمات سیستم اندروید", "Android system settings")) }
        OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Wifi, null); Text(tx("تنظیمات Wi-Fi", "Wi-Fi settings")) }
        OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Bluetooth, null); Text(tx("تنظیمات Bluetooth", "Bluetooth settings")) }
        OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Event, null); Text(tx("ایجاد رویداد در تقویم", "Create calendar event")) }
        Text(tx("این دکمه‌ها صفحه رسمی تنظیمات یا تقویم را باز می‌کنند؛ تغییرات نهایی با تأیید خودت انجام می‌شود.", "These shortcuts open official system settings or Calendar; you confirm any changes."), color = Color.Gray, fontSize = 10.sp)
    }
}

@Composable
private fun SafetyScreen(contact: String, onContact: (String) -> Unit, onDial: (String) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(tx("مرکز ایمنی", "Safety center"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("شماره تماس اضطراری یا فرد مورد اعتماد را ذخیره کن. دکمه تماس فقط شماره‌گیر سیستم را باز می‌کند و بدون اقدام تو تماسی برقرار نمی‌شود.", "Save an emergency or trusted contact. The button opens the system dialer; no call is placed without your action."), color = Color.LightGray, fontSize = 12.sp)
        OutlinedTextField(contact, onContact, modifier = Modifier.fillMaxWidth(), label = { Text(tx("شماره تماس", "Phone number")) }, singleLine = true)
        Button(onClick = { if (contact.isNotBlank()) onDial(contact) }, enabled = contact.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Call, null); Text(tx("باز کردن شماره‌گیر", "Open dialer")) }
        Text(tx("این بخش جایگزین خدمات رسمی اورژانس نیست. اشتراک‌گذاری موقعیت، تماس خودکار و تماس‌گیرنده هوشمند در این نسخه فعال نیستند.", "This is not an emergency service. Location sharing, automatic calling and AI call answering are not enabled in this release."), color = Gold, fontSize = 11.sp)
    }
}


@Composable
private fun MemoryScreen(memories: List<MemoryEntity>, onAdd: (String, String) -> Unit, onDelete: (MemoryEntity) -> Unit, onClear: () -> Unit) {
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Preference") }
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("حافظهٔ تأییدشده", "Approved memory"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("فقط مواردی که خودت اینجا اضافه می‌کنی ذخیره می‌شوند. اطلاعات حساس را وارد نکن.", "Only items you explicitly add here are stored. Avoid sensitive information."), color = Color.LightGray, fontSize = 11.sp)
        OutlinedTextField(content, { content = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("موردی برای ذخیره بنویس", "Memory item to save")) })
        OutlinedTextField(category, { category = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("دسته‌بندی", "Category")) }, singleLine = true)
        Button(onClick = { if (content.isNotBlank()) { onAdd(content.trim(), category.ifBlank { "General" }); content = "" } }, enabled = content.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text(tx("ذخیره در حافظه", "Save to memory")) }
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("جست‌وجو در حافظه", "Search memory")) }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("${memories.size} مورد ذخیره‌شده", "${memories.size} saved items"), color = Cyan, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear, enabled = memories.isNotEmpty()) { Text(tx("حذف همه", "Delete all"), color = Gold) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(memories.filter { it.content.contains(query, true) || it.category.contains(query, true) }, key = { it.id }) { item ->
                Surface(color = SurfaceDark, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(item.category, color = Gold, fontSize = 10.sp); Text(item.content, color = Color.White, fontSize = 13.sp) }
                        IconButton(onClick = { onDelete(item) }) { Icon(Icons.Default.Delete, null, tint = Color.LightGray) }
                    }
                }
            }
        }
    }
}

@Composable
private fun VaultScreen(vaultItems: List<VaultEntity>, onAdd: () -> Unit, onDelete: (VaultEntity) -> Unit, onOpen: (VaultEntity) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(tx("خزانه دانش", "Knowledge vault"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(tx("فایل‌ها با انتخاب مستقیم تو و مجوز URI سیستم ذخیره می‌شوند.", "Files are added through the system picker with a persisted URI grant."), color = Color.Gray, fontSize = 10.sp) }
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text(tx("افزودن", "Add")) }
        }
        if (vaultItems.isEmpty()) EmptyState(tx("هنوز فایلی اضافه نشده است.", "No files added yet."))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vaultItems, key = { it.id }) { item ->
                Surface(color = SurfaceDark, shape = RoundedCornerShape(14.dp), modifier = Modifier.clickable { onOpen(item) }) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = Cyan)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(item.title, color = Color.White, fontSize = 13.sp); Text(item.mimeType.ifBlank { "File" }, color = Color.Gray, fontSize = 10.sp) }
                        IconButton(onClick = { onDelete(item) }) { Icon(Icons.Default.Delete, null, tint = Color.LightGray) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppLauncherScreen() {
    val context = LocalContext.current
    val pm = remember { context.packageManager }
    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val launchables = pm.queryIntentActivities(intent, 0)
        launchables.map { it.activityInfo }.distinctBy { it.packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }
    }
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text(tx("راه‌انداز برنامه‌ها", "App launcher"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("جست‌وجوی برنامه نصب‌شده", "Search installed apps")) }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(apps.filter { it.loadLabel(pm).toString().contains(query, true) }, key = { it.packageName }) { info ->
                Surface(color = SurfaceDark, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable {
                    runCatching { context.startActivity(pm.getLaunchIntentForPackage(info.packageName) ?: error("Launch intent unavailable")) }
                }) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Android, null, tint = Cyan, modifier = Modifier.size(30.dp))
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(info.loadLabel(pm).toString(), color = Color.White); Text(info.packageName, color = Color.Gray, fontSize = 9.sp) }
                        Icon(Icons.Default.OpenInNew, null, tint = Cyan)
                    }
                }
            }
        }
        Text(tx("فقط برنامه‌های دارای آیکون لانچر نمایش داده می‌شوند. اجرای برنامه تابع محدودیت‌های سیستم است.", "Only launcher-visible apps are listed. Launching remains subject to Android restrictions."), color = Color.Gray, fontSize = 10.sp)
    }
}

@Composable
private fun NewsScreen() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val topics = listOf("Technology", "Science", "AI", "World", "Sports", "Gaming", "Business")
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("مرکز اخبار", "News reader"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("جست‌وجوی اخبار در Google News باز می‌شود؛ تاریخ و منبع مقاله را در صفحه اصلی بررسی کن.", "News search opens Google News. Check each article's date and publisher on the source page."), color = Color.LightGray, fontSize = 11.sp)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("موضوع یا عبارت", "Topic or search phrase")) }, singleLine = true)
        Button(onClick = { if (query.isNotBlank()) runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://news.google.com/search?q=${Uri.encode(query)}"))) } }, enabled = query.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Search, null); Text(tx("جست‌وجوی اخبار", "Search news")) }
        Text(tx("موضوعات پیشنهادی", "Suggested topics"), color = Gold, fontWeight = FontWeight.SemiBold)
        topics.forEach { topic -> OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://news.google.com/search?q=${Uri.encode(topic)}"))) } }, modifier = Modifier.fillMaxWidth()) { Text(if (LocalEnglish.current) topic else when(topic) { "Technology" -> "فناوری"; "Science" -> "علم"; "AI" -> "هوش مصنوعی"; "World" -> "جهان"; "Sports" -> "ورزش"; "Gaming" -> "بازی"; else -> "اقتصاد" }) } }
        Text(tx("خلاصه‌سازی درون‌برنامه‌ای و پخش خودکار خبر در این نسخه فعال نیست.", "In-app article extraction, summarization and automatic news playback are not enabled."), color = Color.Gray, fontSize = 10.sp)
    }
}

@Composable
private fun PrivacyScreen(context: Context, onClearChat: () -> Unit, onClearMemory: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("مرکز حریم خصوصی", "Privacy center"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("مجوزها فقط هنگام استفاده از قابلیت مرتبط درخواست می‌شوند. از تنظیمات اندروید می‌توانی آن‌ها را تغییر دهی.", "Permissions are requested only when a related feature is used. You can change them in Android settings."), color = Color.LightGray, fontSize = 11.sp)
        val mic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notifications = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val items = listOf(tx("میکروفون", "Microphone") to if (mic) tx("مجاز", "Granted") else tx("غیرمجاز", "Not granted"), tx("اعلان‌ها", "Notifications") to if (notifications) tx("مجاز یا نیازمند بررسی سیستم", "Granted or system-managed") else tx("غیرمجاز", "Not granted"), tx("دسترسی دوربین", "Camera access") to tx("در این نسخه درخواست نمی‌شود؛ تحلیل از فایل انتخابی است.", "Not requested; image analysis uses user-selected files."), tx("موقعیت مکانی", "Location") to tx("استفاده نمی‌شود", "Not used"), tx("مخاطبین و پیامک", "Contacts and SMS") to tx("استفاده نمی‌شوند", "Not used"), tx("کلید API", "API key") to tx("رمزگذاری‌شده با Android Keystore", "Encrypted with Android Keystore"))
        items.forEach { (label, value) -> Surface(color = SurfaceDark, shape = RoundedCornerShape(12.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = Cyan); Text(value, color = Color.White, fontSize = 11.sp) } } }
        Button(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Security, null); Text(tx("تنظیمات مجوزهای اندروید", "Android app permissions")) }
        OutlinedButton(onClick = onClearChat, modifier = Modifier.fillMaxWidth()) { Text(tx("حذف تاریخچه گفتگو", "Delete chat history")) }
        OutlinedButton(onClick = onClearMemory, modifier = Modifier.fillMaxWidth()) { Text(tx("حذف همه حافظه‌های تأییدشده", "Delete all approved memories")) }
        Text(tx("حذف گفتگو و حافظه قابل بازگشت نیست. فایل‌های خزانه در فضای انتخاب‌شده کاربر باقی می‌مانند تا جداگانه حذف شوند.", "Deleting chat and memory cannot be undone. Vault files remain in their user-selected locations until separately deleted."), color = Gold, fontSize = 10.sp)
    }
}

@Composable
private fun RoutineScreen(context: Context, openTasks: Int, notes: Int, onSchedule: (String, Long) -> Unit) {
    val english = LocalEnglish.current
    val prefs = remember { context.getSharedPreferences("jarvis_routine", Context.MODE_PRIVATE) }
    var hour by remember { mutableStateOf(prefs.getInt("hour", 7).toString()) }
    var minute by remember { mutableStateOf(prefs.getInt("minute", 0).toString()) }
    var greeting by remember { mutableStateOf(prefs.getString("greeting", "صبح بخیر") ?: "Good morning") }
    var includeTasks by remember { mutableStateOf(prefs.getBoolean("tasks", true)) }
    var includeNotes by remember { mutableStateOf(prefs.getBoolean("notes", false)) }
    var saved by remember { mutableStateOf(prefs.getBoolean("configured", false)) }
    val defaultGreeting = tx("صبح بخیر", "Good morning")
    val briefingTitle = tx("گزارش روزانه", "Daily briefing")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("روال صبحگاهی و گزارش روزانه", "Morning routine & daily briefing"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("زمان و محتوای گزارش را تنظیم کن. زمان‌بندی این نسخه یک‌باره است؛ تکرار هفتگی هنوز فعال نیست.", "Configure the briefing. Scheduling in this build is one-time; weekly recurrence is not enabled."), color = Gold, fontSize = 11.sp)
        OutlinedTextField(greeting, { greeting = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("پیام خوشامد", "Greeting")) })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(hour, { hour = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), label = { Text(tx("ساعت (۰ تا ۲۳)", "Hour (0–23)")) })
            OutlinedTextField(minute, { minute = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), label = { Text(tx("دقیقه", "Minute")) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(includeTasks, { includeTasks = it }); Text(tx("گنجاندن وظایف باز ($openTasks)", "Include open tasks ($openTasks)"), color = Color.White) }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(includeNotes, { includeNotes = it }); Text(tx("گنجاندن تعداد یادداشت‌ها ($notes)", "Include note count ($notes)"), color = Color.White) }
        Button(onClick = {
            val h = hour.toIntOrNull()?.coerceIn(0,23) ?: 7
            val m = minute.toIntOrNull()?.coerceIn(0,59) ?: 0
            prefs.edit().putInt("hour", h).putInt("minute", m).putString("greeting", greeting).putBoolean("tasks", includeTasks).putBoolean("notes", includeNotes).putBoolean("configured", true).apply()
            saved = true
        }, modifier = Modifier.fillMaxWidth()) { Text(tx("ذخیره تنظیمات", "Save settings")) }
        OutlinedButton(onClick = {
            val parts = mutableListOf(greeting.ifBlank { defaultGreeting })
            if (includeTasks) parts += if (english) "Open tasks: $openTasks" else "تعداد وظایف باز: $openTasks"
            if (includeNotes) parts += if (english) "Notes: $notes" else "تعداد یادداشت‌ها: $notes"
            val text = parts.joinToString(". ")
            val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            runCatching { context.startActivity(Intent.createChooser(intent, briefingTitle)) }
        }, modifier = Modifier.fillMaxWidth()) { Text(tx("ساخت گزارش همین امروز", "Create today's briefing")) }
        OutlinedButton(onClick = {
            val h = hour.toIntOrNull()?.coerceIn(0,23) ?: 7
            val m = minute.toIntOrNull()?.coerceIn(0,59) ?: 0
            val target = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,h); set(java.util.Calendar.MINUTE,m); set(java.util.Calendar.SECOND,0); if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR,1) }
            onSchedule(if (english) "Your morning briefing is ready" else "زمان گزارش صبحگاهی فرا رسیده است", target.timeInMillis)
        }, modifier = Modifier.fillMaxWidth()) { Text(tx("تنظیم یادآور یک‌باره", "Schedule one-time reminder")) }
        if (saved) Text(tx("تنظیمات ذخیره شد.", "Settings saved."), color = Cyan)
    }
}

@Composable
private fun ModesScreen(active: String, onSelect: (String) -> Unit) {
    val modes = listOf("Normal" to "عادی", "Study" to "مطالعه", "Developer" to "توسعه‌دهنده", "Vision" to "بینایی", "Security" to "امنیت", "Offline" to "آفلاین", "Focus" to "تمرکز")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text(tx("حالت‌های دستیار", "Assistant modes"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("حالت انتخابی به‌عنوان زمینه به مدل هوش مصنوعی فرستاده می‌شود؛ خودش مجوزهای سیستم را تغییر نمی‌دهد.", "The selected mode is sent as AI context; it does not change system permissions."), color = Color.LightGray, fontSize = 11.sp)
        modes.forEach { (id, fa) ->
            Surface(color = if (active == id) Color(0xFF263B50) else SurfaceDark, shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().clickable { onSelect(id) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(if (LocalEnglish.current) id else fa, color = Color.White, fontWeight = FontWeight.SemiBold); Text(id, color = Color.Gray, fontSize = 10.sp) }
                    if (active == id) Icon(Icons.Default.CheckCircle, null, tint = Gold)
                }
            }
        }
    }
}

@Composable
private fun CommunicationsScreen() {
    val english = LocalEnglish.current
    val context = LocalContext.current
    var recipient by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("مرکز ارتباطات", "Communications"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("پیام را آماده کن و با انتخاب خودت در برنامهٔ مناسب باز کن. ارسال خودکار انجام نمی‌شود.", "Prepare a message and open a compatible app yourself. Nothing is sent automatically."), color = Color.LightGray, fontSize = 11.sp)
        OutlinedTextField(recipient, { recipient = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("گیرنده (اختیاری)", "Recipient (optional)")) }, singleLine = true)
        OutlinedTextField(draft, { draft = it }, modifier = Modifier.fillMaxWidth(), minLines = 5, label = { Text(tx("متن پیام", "Message draft")) })
        Button(onClick = {
            val intent = if (recipient.isNotBlank() && !recipient.contains('@')) {
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(recipient)}")).putExtra("sms_body", draft)
            } else {
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, draft).apply {
                    if (recipient.contains('@')) putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                }
            }
            runCatching { context.startActivity(Intent.createChooser(intent, if (english) "Choose an app to share" else "انتخاب برنامه برای اشتراک‌گذاری")) }
        }, enabled = draft.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Text(tx("باز کردن منوی اشتراک‌گذاری", "Open share sheet")) }
        Text(tx("خواندن اعلان‌ها، دسترسی به پیامک و پاسخ خودکار در این نسخه فعال نیست؛ تماس‌گیرندهٔ هوشمند نیز محدودیت‌های جدی اندروید دارد.", "Notification reading, SMS access and auto-replies are not enabled. AI cellular call answering is also heavily restricted by Android."), color = Gold, fontSize = 10.sp)
    }
}

@Composable
private fun CalendarScreen() {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("60") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("ایجاد رویداد تقویم", "Create calendar event"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("رویداد در برنامهٔ تقویم دستگاه باز می‌شود و قبل از ذخیره می‌توانی آن را بررسی کنی.", "The event opens in the device calendar so you can review it before saving."), color = Color.LightGray, fontSize = 11.sp)
        OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("عنوان رویداد", "Event title")) })
        OutlinedTextField(description, { description = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("توضیحات", "Description")) })
        OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(5) }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("شروع چند دقیقه بعد؟", "Start in how many minutes?")) })
        Button(onClick = {
            val start = System.currentTimeMillis() + (minutes.toLongOrNull() ?: 60L).coerceIn(0,525600) * 60_000L
            val intent = Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
                .putExtra(android.provider.CalendarContract.Events.TITLE, title)
                .putExtra(android.provider.CalendarContract.Events.DESCRIPTION, description)
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, start + 3_600_000L)
            runCatching { context.startActivity(intent) }
        }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Event, null); Text(tx("ادامه در تقویم", "Continue in Calendar")) }
    }
}

@Composable
private fun VideoModuleScreen() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf("") }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri -> selected = uri?.toString().orEmpty() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("ترجمه و دوبلهٔ ویدیو", "Video translation & dubbing"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("می‌توانی فایل ویدیویی را با انتخاب‌گر اندروید انتخاب کنی؛ اما زنجیرهٔ استخراج صدا، پیاده‌سازی گفتار، ترجمه، هم‌زمان‌سازی و خروجی نهایی هنوز در این نسخه پیاده‌سازی نشده است.", "You can select a video, but audio extraction, transcription, translation, alignment and final export are not implemented in this build."), color = Gold, fontSize = 12.sp)
        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.VideoLibrary, null); Text(tx("انتخاب ویدیو", "Choose video")) }
        if (selected.isNotBlank()) Text(tx("فایل انتخاب شد؛ هنوز پردازش انجام نشده است.", "File selected; no processing has been performed."), color = Cyan, fontSize = 11.sp)
        Text(tx("برای دوبلهٔ قابل‌استفاده به موتور پردازش صوت/ویدیو، فضای ذخیره‌سازی کافی و احتمالاً مدل یا سرویس گفتار نیاز است. هیچ سرویس پولی بدون اجازه فعال نمی‌شود.", "A usable dubbing pipeline requires audio/video processing, sufficient storage and potentially speech models or services. No paid service is enabled without consent."), color = Color.LightGray, fontSize = 11.sp)
    }
}

@Composable
private fun CallReceptionScreen() {
    val context = LocalContext.current
    var number by remember { mutableStateOf("") }
    var showConfirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("مدیریت تماس با کنترل کاربر", "User-controlled call tools"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("جارویس می‌تواند شماره‌گیر رسمی اندروید را باز کند؛ تماس فقط پس از بررسی و فشردن دکمهٔ تماس توسط خودت برقرار می‌شود.", "JARVIS can open Android's system dialer. The call is placed only if you review the number and press the call button yourself."), color = Cyan, fontSize = 12.sp)
        OutlinedTextField(number, { number = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(tx("شماره تلفن", "Phone number")) })
        Button(onClick = { showConfirm = true }, enabled = number.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Phone, null); Text(tx("بازکردن شماره‌گیر", "Open dialer")) }
        if (showConfirm) AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text(tx("تأیید بازکردن شماره‌گیر", "Confirm dialer")) },
            text = { Text(tx("شمارهٔ زیر در برنامهٔ تماس اندروید باز می‌شود. جارویس خودش تماس نمی‌گیرد: $number", "This number will be opened in Android's dialer. JARVIS will not place the call: $number")) },
            confirmButton = { TextButton(onClick = {
                showConfirm = false
                runCatching { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))) }
            }) { Text(tx("ادامه", "Continue")) } },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text(tx("لغو", "Cancel")) } }
        )
        Divider()
        Text(tx("محدودیت‌ها", "Limitations"), color = Gold, fontWeight = FontWeight.SemiBold)
        Text(tx("پاسخ خودکار، شنیدن صدای تماس سلولی، انتقال تماس و ضبط تماس در این نسخه فعال نیستند. دسترسی‌های اندروید و قوانین حریم خصوصی این قابلیت‌ها را محدود می‌کنند.", "Auto-answer, cellular call-audio access, call transfer and call recording are not enabled. Android permissions and privacy rules restrict these capabilities."), color = Color.LightGray, fontSize = 12.sp)
        Text(tx("هیچ تماسی بدون اقدام مستقیم تو برقرار نمی‌شود.", "No call is placed without your direct action."), color = Color.LightGray, fontSize = 11.sp)
    }
}

@Composable
private fun ModulesScreen() {
    val modules = listOf(
        Triple("AI Chat / Provider", "گفتگو با API سازگار؛ نیازمند کلید و احتمال هزینه", true),
        Triple("Voice STT / TTS", "تشخیص گفتار و خواندن پاسخ با سرویس‌های نصب‌شده؛ push-to-talk", true),
        Triple("Vision / Live Camera OCR", "CameraX preview + OCR محلی برای خط لاتین؛ OCR فارسی تضمین نیست", true),
        Triple("Notes / Tasks / Memory", "ذخیره‌سازی محلی Room", true),
        Triple("Reminders", "یادآور یک‌باره و بازیابی پس از راه‌اندازی مجدد", true),
        Triple("App Launcher / Device", "اجرای برنامه‌ها و تنظیمات رسمی اندروید", true),
        Triple("Web Research", "مرور HTTPS داخلی و خلاصه‌سازی متن صفحه با تأیید کاربر", true),
        Triple("Multi-step Planner", "برنامهٔ محلی یادداشت/وظیفه/یادآور با تأیید قبل از اجرا", true),
        Triple("Encrypted Backup / WebDAV", "AES-256-GCM فایل + بارگذاری/دریافت دستی HTTPS WebDAV", true),
        Triple("Manual Location Share", "اشتراک‌گذاری آخرین موقعیت ذخیره‌شده با انتخاب گیرنده", true),
        Triple("Offline Commands", "ساعت، تاریخ و محاسبات قطعی؛ بدون مدل زبانی مولد", true),
        Triple("Wake Word Always-on", "شنود پس‌زمینه و تشخیص واژهٔ بیدارباش پیاده‌سازی نشده", false),
        Triple("Offline Generative LLM", "مدل زبانی محلی و وزن‌های مدل همراه برنامه نیست", false),
        Triple("Video Dubbing / Export", "ترجمهٔ گفتار، هم‌زمان‌سازی و رندر ویدیوی دوبله‌شده تکمیل نشده", false),
        Triple("AI Cellular Receptionist", "محدودیت API اندروید برای پاسخ و دسترسی به صدای تماس؛ فعال نیست", false),
        Triple("Automatic Emergency Dispatch", "ارسال خودکار موقعیت/تماس اضطراری فعال نیست", false),
        Triple("Automatic Cloud Sync", "همگام‌سازی خودکار ابری فعال نیست؛ پشتیبان رمزگذاری‌شده دستی است", false)
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(tx("وضعیت ماژول‌ها", "Module status"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("وضعیت واقعی قابلیت‌ها؛ موارد غیرفعال به‌عنوان قابلیت آماده معرفی نمی‌شوند.", "Actual capability status. Disabled items are not presented as ready features."), color = Color.LightGray, fontSize = 11.sp)
        modules.forEach { (name, detail, ready) ->
            Surface(color = SurfaceDark, shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (ready) Icons.Default.CheckCircle else Icons.Default.Info, null, tint = if (ready) Cyan else Gold)
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(if (LocalEnglish.current) name else name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text(if (LocalEnglish.current) detail else detail, color = Color.Gray, fontSize = 10.sp)
                    }
                    Text(if (ready) tx("فعال", "Ready") else tx("باقی‌مانده", "Pending"), color = if (ready) Cyan else Gold, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun JourneyScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("jarvis_safe_journey", Context.MODE_PRIVATE) }
    var destination by remember { mutableStateOf(prefs.getString("destination", "") ?: "") }
    var etaMinutes by remember { mutableStateOf("45") }
    var active by remember { mutableStateOf(prefs.getBoolean("active", false)) }
    var arrivalAt by remember { mutableStateOf(prefs.getLong("arrival_at", 0L)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(tx("جلسهٔ سفر امن", "Safe journey session"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(tx("این قابلیت یادآور محلی رسیدن می‌سازد. اشتراک‌گذاری موقعیت جداگانه، دستی و فقط با انتخاب گیرنده انجام می‌شود.", "This creates a local arrival reminder. Location sharing is separate, manual, and requires choosing a recipient."), color = Color.LightGray, fontSize = 11.sp)
        OutlinedTextField(destination, { destination = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("مقصد یا عنوان مسیر", "Destination or trip label")) })
        OutlinedTextField(etaMinutes, { etaMinutes = it.filter(Char::isDigit).take(5) }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("زمان تقریبی رسیدن (دقیقه)", "Estimated arrival (minutes)")) })
        Button(onClick = {
            val mins = (etaMinutes.toLongOrNull() ?: 45L).coerceIn(1, 10080)
            arrivalAt = System.currentTimeMillis() + mins * 60_000L
            active = true
            prefs.edit().putString("destination", destination).putLong("arrival_at", arrivalAt).putBoolean("active", true).apply()
            ReminderStore.add(context, if (destination.isBlank()) "زمان بررسی رسیدن فرا رسیده است" else "زمان بررسی رسیدن به $destination فرا رسیده است", arrivalAt)
        }, enabled = !active, modifier = Modifier.fillMaxWidth()) { Text(tx("شروع جلسه و یادآور رسیدن", "Start session & arrival reminder")) }
        if (active) {
            Text(tx("جلسه فعال است — زمان یادآور: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(arrivalAt))}", "Session active — reminder: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(arrivalAt))}"), color = Cyan, fontSize = 12.sp)
            OutlinedButton(onClick = { active = false; prefs.edit().putBoolean("active", false).apply() }, modifier = Modifier.fillMaxWidth()) { Text(tx("تأیید رسیدن و پایان جلسه", "Confirm arrival & end session")) }
        }
        ExplicitLocationShare(context)
        Text(tx("موقعیت فقط پس از فشردن دکمه و انتخاب گیرنده در برگهٔ اشتراک‌گذاری ارسال می‌شود. ارسال خودکار اضطراری فعال نیست.", "Location is shared only after pressing the button and choosing a recipient. Automatic emergency sharing is not enabled."), color = Gold, fontSize = 10.sp)
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(25.dp), contentAlignment = Alignment.Center) { Text(text, color = Color.Gray, fontSize = 12.sp) }
}

@Composable
private fun SettingsScreen(baseUrl: String, onBaseUrl: (String) -> Unit, model: String, onModel: (String) -> Unit, apiKey: String, onApiKey: (String) -> Unit, onTest: () -> Unit, busy: Boolean) {
    Column(Modifier.fillMaxSize()) {
        Text(tx("تنظیمات هوش مصنوعی", "AI Settings"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(tx("سرویس‌های سازگار با قالب OpenAI Chat Completions", "Providers compatible with OpenAI Chat Completions"), color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        OutlinedTextField(baseUrl, onBaseUrl, Modifier.fillMaxWidth(), label = { Text(tx("آدرس پایه API", "API base URL")) }, singleLine = true)
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(model, onModel, Modifier.fillMaxWidth(), label = { Text(tx("نام مدل", "Model name")) }, singleLine = true)
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(apiKey, onApiKey, Modifier.fillMaxWidth(), label = { Text(tx("کلید API", "API key")) }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        Spacer(Modifier.height(12.dp))
        Button(onClick = onTest, enabled = !busy && apiKey.isNotBlank() && model.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.CloudDone, null); Spacer(Modifier.width(8.dp)); Text(if (busy) tx("در حال بررسی…", "Testing…") else tx("آزمایش اتصال", "Test connection"))
        }
        Spacer(Modifier.height(15.dp))
        Text(tx("امنیت و هزینه", "Security & cost"), color = Gold, fontWeight = FontWeight.SemiBold)
        Text(tx("• کلید API با Android Keystore رمزگذاری و روی همین دستگاه نگهداری می‌شود.\n• درخواست‌ها مستقیماً از گوشی به سرویس انتخابی ارسال می‌شوند؛ سرویس‌دهنده API ممکن است متن گفتگو را پردازش کند.\n• رمزگذاری محلی، کلید را در برابر تمام روش‌های استخراج از دستگاه یا APK مصون نمی‌کند. برای انتشار عمومی، استفاده از سرور واسط امن توصیه می‌شود.\n• هزینه و محدودیت استفاده را در پنل سرویس‌دهنده بررسی کنید. برنامه بدون اجازه شما اشتراک یا خریدی انجام نمی‌دهد.\n• آدرس باید HTTPS و سرویس باید endpoint سازگار /chat/completions داشته باشد.", "• Your API key is encrypted with Android Keystore and stored on this device.\n• Requests go directly from your phone to the selected provider, which may process conversation content.\n• Local encryption cannot protect against every device compromise or extraction method. A secure backend proxy is recommended for public distribution.\n• Check provider pricing and usage limits. The app does not subscribe or purchase services for you.\n• Use HTTPS and an OpenAI-compatible /chat/completions endpoint."), color = Color.LightGray, fontSize = 11.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(15.dp))
        Text(tx("امکانات محلی", "Local features"), color = Gold, fontWeight = FontWeight.SemiBold)
        Text(tx("یادداشت‌ها، وظایف، رابط کاربری و یادآور محلی بدون API قابل استفاده‌اند. تشخیص گفتار و صدای فارسی به سرویس‌های نصب‌شده روی گوشی وابسته است.", "Notes, tasks, UI and local reminders work without an AI API. Speech recognition and Persian TTS depend on services installed on the device."), color = Color.LightGray, fontSize = 11.sp, lineHeight = 18.sp)
    }
}
