package com.jarvis.ai

import com.jarvis.ai.security.EncryptedBackup
import org.junit.Assert.*
import org.junit.Test

class EncryptedBackupTest {
    @Test fun encryptDecryptRoundTrip() {
        val plain = "jarvis backup test".toByteArray()
        val encrypted = EncryptedBackup.encrypt(plain, "safe-passphrase-2026".toCharArray())
        assertFalse(plain.contentEquals(encrypted))
        assertArrayEquals(plain, EncryptedBackup.decrypt(encrypted, "safe-passphrase-2026".toCharArray()))
    }
    @Test(expected = Exception::class) fun wrongPasswordMustFail() {
        val encrypted = EncryptedBackup.encrypt("secret".toByteArray(), "safe-passphrase-2026".toCharArray())
        EncryptedBackup.decrypt(encrypted, "another-passphrase".toCharArray())
    }
}
