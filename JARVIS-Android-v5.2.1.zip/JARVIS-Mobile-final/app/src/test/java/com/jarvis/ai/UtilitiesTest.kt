package com.jarvis.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertNull
import org.junit.Test

class UtilitiesTest {
    @Test fun evaluatesOperatorPrecedenceAndParentheses() {
        assertEquals(15.0, JarvisCalculator.evaluate("(12 + 8) / 4 * 3"), 0.000001)
    }

    @Test fun evaluatesUnaryAndDecimalNumbers() {
        assertEquals(-2.5, JarvisCalculator.evaluate("-5 / 2"), 0.000001)
    }

    @Test fun rejectsDivisionByZero() {
        assertThrows(IllegalArgumentException::class.java) { JarvisCalculator.evaluate("5 / 0") }
    }

    @Test fun rejectsTrailingCharacters() {
        assertThrows(IllegalArgumentException::class.java) { JarvisCalculator.evaluate("2 + 3xyz") }
    }

    @Test fun offlineAssistantAnswersTimeLocally() {
        assertEquals(true, OfflineCommandEngine.answer("what time is it")?.contains("زمان فعلی دستگاه") == true)
    }

    @Test fun offlineCalculatorUnderstandsPersianDigits() {
        assertEquals("نتیجه: 4.0", OfflineCommandEngine.answer("۲+۲"))
    }

    @Test fun offlineAssistantDoesNotPretendToBeGenerative() {
        assertNull(OfflineCommandEngine.answer("Explain quantum physics in detail"))
    }

    @Test fun reminderDelayUnderstandsPersianDigitsAndMinutes() {
        assertEquals(30 * 60_000L, reminderDelayMillis("یادآور ۳۰ دقیقه بعد"))
    }

    @Test fun reminderDelayUnderstandsTomorrow() {
        assertEquals(24 * 60 * 60_000L, reminderDelayMillis("remind me tomorrow"))
    }
}
