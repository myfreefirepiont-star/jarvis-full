# Security Policy

Please do not publish API keys, passwords, personal data, or exploitable security details in public issues.

For a security concern, contact the repository owner privately through GitHub's private vulnerability reporting feature, if enabled. Include affected version, impact, and reproduction details. Never include real credentials in reports.

The app is a client application. Keystore encryption protects locally stored API credentials at rest but does not make a distributed client a secure place for provider-wide secrets. Do not embed shared production credentials in the app. Use a controlled backend for public deployments.
